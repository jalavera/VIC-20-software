#!/usr/bin/env python3
"""VINTIUNA PRO - compressor aritmetic (LZ + codificador binari adaptatiu), per a unpack.

Els tokens son com els de blz.py (literal; repeticio amb longitud, part alta i part baixa de
la distancia; fi = longitud gamma de 256), pero cada decisio binaria es codifica amb un
codificador aritmetic binari amb probabilitats adaptatives de 8 bits (P(1) = p/256):
  b8 = (rng/256 * (p/8)) / 32 (enters: nomes 5 bits de p, perque el 6502 multipliqui de pressa);  1: rng = b8*256;  0: cod -= b8*256, rng -= b8*256
  1: p += (255-p)>>4;  0: p -= p>>4;  mentre rng < $8000: rng*2, cod*2 + bit seguent
rng i cod son de 16 bits (rng = $ffff al principi; cod = els 16 primers bits del flux).
Contextos (NCTX probabilitats, a 128 al principi):
  0/1 tipus de token (darrere d'un literal / d'una repeticio), LENB+2k/LENB+2k+1 gamma de
  la longitud (continuar/bit), HIB igual per a la part alta, LOB+(c&31) arbre de la part
  baixa, LITB+(c&127) arbre dels literals.
El descompressor llegeix exactament els bits que escriu el compressor. Al mateix lloc no hi
ha marca de fi (es llegiria despres de les darreres escriptures, que la trepitjarien): el
flux acaba on acaba el desti i s'atura quan l'escriptura arriba a la lectura."""
import math
import blz

LENB, HIB, LOB, LITB, NCTX = 2, 18, 34, 66, 194

def decisions(data, toks, marker=True):
    out = []
    i = 0
    pm = 0
    def tree8(v, base, mask):
        c = 1
        for k in range(7, -1, -1):
            b = (v >> k) & 1
            out.append((base + (c & mask), b))
            c = c * 2 + b
    def gam(v, base):
        k = 0
        for j in range(v.bit_length() - 2, -1, -1):
            out.append((base + 2 * k, 0))
            out.append((base + 2 * k + 1, (v >> j) & 1))
            k += 1
        out.append((base + 2 * k, 1))
    for t in toks:
        out.append((pm, 1 if t[0] == 'M' else 0))
        if t[0] == 'L':
            tree8(data[i], LITB, 127)
            i += 1
            pm = 0
        else:
            _, L, o = t
            gam(L - 1, LENB)
            gam(((o - 1) >> 8) + 1, HIB)
            tree8((o - 1) & 255, LOB, 31)
            i += L
            pm = 1
    if marker:
        out.append((pm, 1))                  # fi: repeticio amb longitud 256
        for k in range(8):
            out.append((LENB + 2 * k, 0))
            out.append((LENB + 2 * k + 1, 0))
    assert i == len(data)
    return out

def upd(p, b):
    return p + ((255 - p) >> 4) if b else p - (p >> 4)

def adaptive_cost(dec):
    P = [128] * NCTX
    bits = 0.0
    cnt = [[0, 0] for _ in range(NCTX)]
    for c, b in dec:
        p = P[c]
        bits += -math.log2((p if b else 256 - p) / 256)
        P[c] = upd(p, b)
        cnt[c][b] += 1
    return bits, cnt

def optparse(x, cnt):
    """tria de tokens amb costos fixos estimats (de la passada anterior)"""
    N = len(x)
    cb = [[-math.log2((cnt[c][b] + .4) / (cnt[c][0] + cnt[c][1] + .8)) for b in (0, 1)] for c in range(NCTX)]
    def tree8c(v, base, mask):
        c = 1
        s = 0
        for k in range(7, -1, -1):
            b = (v >> k) & 1
            s += cb[base + (c & mask)][b]
            c = c * 2 + b
        return s
    litc = [tree8c(v, LITB, 127) for v in range(256)]
    loc = [tree8c(v, LOB, 31) for v in range(256)]
    def gamc(v, base):
        k = 0
        s = 0
        for j in range(v.bit_length() - 2, -1, -1):
            s += cb[base + 2 * k][0] + cb[base + 2 * k + 1][(v >> j) & 1]
            k += 1
        return s + cb[base + 2 * k][1]
    lenc = [0, 0] + [gamc(L - 1, LENB) for L in range(2, 257)]
    hic = [gamc(h + 1, HIB) for h in range(15)]
    INF = 1e18
    cost = [[INF, INF] for _ in range(N + 1)]
    cost[N] = [0, 0]
    ch = [[None, None] for _ in range(N + 1)]
    pos = {}
    cand = [None] * N
    for i in range(N - 1):
        k = x[i] | x[i + 1] << 8
        cand[i] = pos.get(k, [])[::-1]
        pos.setdefault(k, []).append(i)
    for i in range(N - 1, -1, -1):
        opts = [(litc[x[i]], ('L',), 1, 0)]
        best = 1
        for j in (cand[i] or ()):
            o = i - j
            l = 0
            while l < 256 and i + l < N and x[i + l - o] == x[i + l]:
                l += 1
            if l > best:
                base = hic[(o - 1) >> 8] + loc[(o - 1) & 255]
                for L in range(best + 1, l + 1):
                    opts.append((lenc[L] + base, ('M', L, o), L, 1))
                best = l
                if best == 256:
                    break
        for pm in (0, 1):
            bc = INF
            bt = None
            for c, t, L, ns in opts:
                cc = c + cb[pm][ns] + cost[i + L][ns]
                if cc < bc:
                    bc = cc
                    bt = t
            cost[i][pm] = bc
            ch[i][pm] = bt
    toks = []
    i = 0
    pm = 0
    while i < N:
        t = ch[i][pm]
        toks.append(t)
        i += 1 if t[0] == 'L' else t[1]
        pm = 1 if t[0] == 'M' else 0
    return toks

def parse(x, iters=3):
    toks = blz.parse(x)
    best = None
    for it in range(iters + 1):
        bits, cnt = adaptive_cost(decisions(x, toks))
        if best is None or bits < best[0]:
            best = (bits, toks)
        if it < iters:
            toks = optparse(x, cnt)
    return best[1]

def encode(x, toks=None, marker=True):
    if toks is None:
        toks = parse(x)
    P = [128] * NCTX
    low = 0
    rng = 0xffff
    shifts = 0
    for c, b in decisions(x, toks, marker):
        p = P[c]
        b8 = ((rng >> 8) * (p >> 3)) >> 5
        if b:
            rng = b8 << 8
        else:
            low += b8 << 8
            rng -= b8 << 8
        P[c] = upd(p, b)
        while rng < 0x8000:
            rng <<= 1
            low <<= 1
            shifts += 1
    nb = 16 + shifts                         # bits que llegira el descompressor
    v = low
    assert v < (1 << nb)
    nbytes = (nb + 7) // 8
    return (v << (nbytes * 8 - nb)).to_bytes(nbytes, 'big')

def decode(comp, base=None, start=None, limit=None, meet=False):
    """descompressor de referencia, exactament com el del 6502. Si base/start: comprova que
    mai s'escriu a un byte del flux encara no llegit (descompressio al mateix lloc)."""
    st = {'r': 0, 'bits': 0}
    out = bytearray()
    def getbit():
        v = st['bits'] << 1
        if v & 0xff == 0:
            x = comp[st['r']]
            st['r'] += 1
            v = (x << 1) | 1
        st['bits'] = v & 0xff
        return (v >> 8) & 1
    P = [128] * NCTX
    rng = 0xffff
    cod = 0
    for _ in range(16):
        cod = (cod << 1) | getbit()
    def decbit(c):
        nonlocal rng, cod
        p = P[c]
        b8 = ((rng >> 8) * (p >> 3)) >> 5
        if (cod >> 8) < b8:
            b = 1
            rng = b8 << 8
        else:
            b = 0
            cod -= b8 << 8
            rng -= b8 << 8
        P[c] = upd(p, b)
        while rng < 0x8000:
            rng = (rng << 1) & 0xffff
            cod = ((cod << 1) | getbit()) & 0xffff
        return b
    def put(x):
        if base is not None:
            w = base + len(out)
            if limit is None or w < limit:
                assert w < start + st['r'], 'trepitja el flux: escriu %d, llegit fins %d' % (w, start + st['r'])
        out.append(x)
    def dec8(base_, mask):
        c = 1
        for _ in range(8):
            c = c * 2 + decbit(base_ + (c & mask))
        return c & 255
    def gamma(b_):
        g = 1
        x = b_
        while True:
            if decbit(x):
                return g
            g = (g << 1) | decbit(x + 1)
            x += 2
            if g >= 256:
                return 0
    pm = 0
    while True:
        if meet and base + len(out) == start + st['r']:
            break                            # l'escriptura ha arribat a la lectura: fi
        f = decbit(pm)
        pm = f
        if not f:
            put(dec8(LITB, 127))
            continue
        g = gamma(LENB)
        if g == 0:
            break
        L = g + 1
        h = gamma(HIB) - 1
        o = h * 256 + dec8(LOB, 31) + 1
        for _ in range(L):
            put(out[-o])
    return bytes(out), st['r']

def inplace(region):
    """Descompressio al mateix lloc: el flux va al final de region i s'acaba quan
    l'escriptura arriba a la lectura (sense marca de fi). Torna (flux, inici): el que hi ha
    davant d'inici es lliure (s'hi pot posar el que nomes cal abans de descomprimir)."""
    toks = parse(region)
    c = encode(region, toks, marker=False)
    st = len(region) - len(c)
    out, r = decode(c, base=0, start=st, meet=True)
    assert out == region and r == len(c), 'la lectura i l\'escriptura es troben abans del final'
    return c, st

if __name__ == '__main__':
    import sys
    d = open(sys.argv[1], 'rb').read()
    c = encode(d)
    assert decode(c)[0] == d
    print(len(d), '->', len(c))

# ---------------- flux de segments (el que fa servir l'arrencada) ----------------
# adreca de desti (2 bytes en arbre de literals), dades amb marca de fi, ...; adreca 0 = fi.
# Les probabilitats continuen d'un segment a l'altre.
def tree_dec(v, base=LITB, mask=127):
    out = []
    c = 1
    for k in range(7, -1, -1):
        b = (v >> k) & 1
        out.append((base + (c & mask), b))
        c = c * 2 + b
    return out

def encode_decisions(dec):
    P = [128] * NCTX
    low = 0
    rng = 0xffff
    shifts = 0
    for c, b in dec:
        p = P[c]
        b8 = ((rng >> 8) * (p >> 3)) >> 5
        if b:
            rng = b8 << 8
        else:
            low += b8 << 8
            rng -= b8 << 8
        P[c] = upd(p, b)
        while rng < 0x8000:
            rng <<= 1
            low <<= 1
            shifts += 1
    nb = 16 + shifts
    nbytes = (nb + 7) // 8
    return (low << (nbytes * 8 - nb)).to_bytes(nbytes, 'big')

def encode_segments(segs):
    dec = []
    for dest, data in segs:
        assert dest >> 8
        dec += tree_dec(dest & 255) + tree_dec(dest >> 8)
        dec += decisions(data, parse(data), marker=True)
    dec += tree_dec(0) + tree_dec(0)
    return encode_decisions(dec)

def decode_mem(mem, addr):
    """com el 6502: llegeix el flux de mem[addr...] i escriu a mem. Torna l'adreca final."""
    st = {'r': addr, 'bits': 0}
    def getbit():
        v = st['bits'] << 1
        if v & 0xff == 0:
            v = (mem[st['r']] << 1) | 1
            st['r'] += 1
        st['bits'] = v & 0xff
        return (v >> 8) & 1
    P = [128] * NCTX
    S = {'rng': 0xffff, 'cod': 0}
    for _ in range(16):
        S['cod'] = (S['cod'] << 1) | getbit()
    def decbit(c):
        p = P[c]
        b8 = ((S["rng"] >> 8) * (p >> 3)) >> 5
        if (S['cod'] >> 8) < b8:
            b = 1
            S['rng'] = b8 << 8
        else:
            b = 0
            S['cod'] -= b8 << 8
            S['rng'] -= b8 << 8
        P[c] = upd(p, b)
        while S['rng'] < 0x8000:
            S['rng'] = (S['rng'] << 1) & 0xffff
            S['cod'] = ((S['cod'] << 1) | getbit()) & 0xffff
        return b
    def dec8(base, mask):
        c = 1
        for _ in range(8):
            c = c * 2 + decbit(base + (c & mask))
        return c & 255
    def gamma(b_):
        g = 1
        x = b_
        while True:
            if decbit(x):
                return g
            g = (g << 1) | decbit(x + 1)
            x += 2
            if g >= 256:
                return 0
    while True:
        zd = dec8(LITB, 127)
        zd |= dec8(LITB, 127) << 8
        if zd >> 8 == 0:
            return st['r']
        pm = 0
        while True:
            if not decbit(pm):
                mem[zd] = dec8(LITB, 127)
                zd += 1
                pm = 0
                continue
            g = gamma(LENB)
            if g == 0:
                break
            h = gamma(HIB) - 1
            o = h * 256 + dec8(LOB, 31) + 1
            for _ in range(g + 1):
                mem[zd] = mem[zd - o]
                zd += 1
            pm = 1
