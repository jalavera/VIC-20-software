; ---- generat per genera_caracters.py: no editar a ma ----
C_BLANK  = 0
C_FELT   = 1
C_TL     = 2
C_TR     = 71
C_BL     = 6
C_BR     = 72
C_T      = 8
C_B      = 9
C_L      = 73
C_SUIT0  = 11
C_SUIT1  = 12
C_SUIT2  = 13
C_SUIT3  = 14
C_TEN    = 15
C_RAIL   = 17
C_RAILB  = 18
C_TLF    = 99
C_BLF    = 100
C_SEP    = 101
C_BTL    = 23
C_BT     = 24
C_BTR    = 26
C_BL_    = 27
C_BI     = 28
C_BR_    = 29
C_BBL    = 30
C_BB     = 31
C_BBR    = 32
K_C      = 64          ; lletra clau en invers
K_N      = 65          ; lletra clau en invers
K_D      = 4          ; lletra clau en invers
K_P      = 16          ; lletra clau en invers
K_S      = 19          ; lletra clau en invers
K_Y      = 25          ; lletra clau en invers
K_E      = 5          ; lletra clau en invers
rankch   !byte $81,$b2,$b3,$b4,$b5,$b6,$b7,$b8,$b9,$0f,$8a,$91,$8b
cardtab  = bigtab
bigtab   !byte $00,$21,$00,$4a,$01,$66,$4b,$25,$67,$4c,$28,$68,$4d,$01,$69,$00,$2c,$00
         !byte $00,$2d,$00,$4e,$01,$6a,$4f,$31,$6b,$00,$33,$00,$50,$01,$6c,$00,$36,$00
facetab  !byte $37,$38,$39,$51,$3b,$6d,$52,$3e,$6e,$53,$44,$6f,$54,$03,$70,$07,$0a,$07,$14,$15,$14,$07,$07,$07,$16,$16,$16
         !byte $55,$22,$71,$56,$23,$72,$57,$24,$73,$58,$26,$74,$59,$27,$75,$5a,$29,$76,$5b,$2a,$77,$5c,$2b,$78,$2e,$16,$2f
         !byte $5d,$30,$79,$5e,$32,$7a,$5f,$34,$7b,$60,$35,$7c,$61,$00,$7d,$62,$3a,$7e,$07,$3c,$3d,$07,$3c,$42,$43,$45,$46
facecol  !byte $0e,$0f,$0e,$0a,$1a,$1a,$1a,$1a,$1a
         !byte $0f,$0f,$0e,$0a,$1c,$1c,$1c,$1c,$1c
         !byte $0f,$0f,$0e,$0a,$1a,$1e,$1e,$1e,$1e
pipdat   !byte $50,$15,$50,$14,$58,$95,$58,$94,$58,$96,$58,$86,$48,$86,$98,$98,$88,$89
PROB     = $1f18          ; probabilitats del descompressor (despres hi van els miralls)
MIRSRC   = 71          ; caracters originals dels miralls
MIRDST   = 99          ; miralls (els genera l'arrencada)
NMIR     = 28
NMIRH    = 10          ; els primers, d'alta resolucio; la resta multicolor
