#!/usr/bin/env python3
"""VINTIUNA PRO - compressor de bits (LZ amb codis gamma), per a unpack del programa.

Format: un flux de bytes on s'intercalen bytes de bits (es llegeixen de 8 en 8, el bit 7
primer, quan se n'acaben) i bytes sencers (literals i part baixa de la distancia).
  bit 0            literal: el byte seguent del flux
  bit 1            repeticio: gamma(L-1), gamma(H+1), byte B;  distancia = H*256+B+1, L = 2..256
  bit 1 + gamma 256  fi (17 bits: 1 i setze zeros)
gamma(v), v>=1: per cada bit de v per sota de l'1 de mes pes, un 0 i el bit; despres un 1.
Si el bloc es descomprimeix al mateix lloc, els zeros del final els donen els dos primers
bytes de la cua (que han de ser 0), que no es toquen mai."""

def gbits(v):
    assert v >= 1
    return 2 * (v.bit_length() - 1) + 1

def mcost(L, o):
    return 1 + gbits(L - 1) + gbits(((o - 1) >> 8) + 1) + 8

def parse(data):
    """tria optima de literals i repeticions (en bits)"""
    N = len(data)
    INF = 1 << 60
    cost = [INF] * (N + 1)
    cost[N] = 0
    ch = [None] * (N + 1)
    pos = {}                       # parella de bytes -> posicions anteriors (la mes propera primer)
    cand = [None] * N
    for i in range(N - 1):
        k = data[i] | data[i + 1] << 8
        cand[i] = pos.get(k, [])[::-1]
        pos.setdefault(k, []).append(i)
    for i in range(N - 1, -1, -1):
        cost[i] = 9 + cost[i + 1]
        ch[i] = ('L',)
        best = 1
        for j in (cand[i] or ()):
            o = i - j
            l = 0
            while l < 256 and i + l < N and data[i + l - o] == data[i + l]:
                l += 1
            if l > best:
                for L in range(best + 1, l + 1):
                    c = mcost(L, o) + cost[i + L]
                    if c < cost[i]:
                        cost[i] = c
                        ch[i] = ('M', L, o)
                best = l
                if best == 256:
                    break
    toks = []
    i = 0
    while i < N:
        t = ch[i]
        toks.append(t)
        i += 1 if t[0] == 'L' else t[1]
    return toks

class Bits:
    def __init__(s):
        s.out = bytearray()
        s.pos = None
        s.n = 8
    def bit(s, b):
        if s.n == 8:
            s.out.append(0)
            s.pos = len(s.out) - 1
            s.n = 0
        if b:
            s.out[s.pos] |= 0x80 >> s.n
        s.n += 1
    def byte(s, x):
        s.out.append(x)
    def gamma(s, v):
        for k in range(v.bit_length() - 2, -1, -1):
            s.bit(0)
            s.bit((v >> k) & 1)
        s.bit(1)

def encode(data, inplace=False):
    """inplace: els 16 zeros finals no van al flux (els donen els 2 zeros de la cua)"""
    b = Bits()
    i = 0
    for t in parse(data):
        if t[0] == 'L':
            b.bit(0)
            b.byte(data[i])
            i += 1
        else:
            _, L, o = t
            b.bit(1)
            b.gamma(L - 1)
            b.gamma(((o - 1) >> 8) + 1)
            b.byte((o - 1) & 255)
            i += L
    b.bit(1)                       # fi: 1 i setze zeros
    if not inplace:
        for _ in range(16):
            b.bit(0)
    return bytes(b.out)

def decode(comp, after=b'', base=None, start=None):
    """descompressor de referencia (com el del 6502). after: bytes que segueixen el flux
    (al mateix lloc, la cua). Si base/start: comprova que el desti (que comenca a base)
    no trepitja mai un byte del flux (que comenca a start) encara no llegit."""
    src = comp + after
    st = {'r': 0, 'bits': 0x80}
    out = bytearray()
    def rd():
        x = src[st['r']]
        st['r'] += 1
        return x
    def getbit():
        v = st['bits'] << 1
        if v & 0xff == 0:
            x = rd()
            v = (x << 1) | 1
            st['bits'] = v & 0xff
            return (v >> 8) & 1
        st['bits'] = v & 0xff
        return (v >> 8) & 1
    def gamma():
        g = 1
        while True:
            if getbit():
                return g
            g = (g << 1) | getbit()
            if g >= 256:
                return 0
    def put(x):
        if base is not None:
            w = base + len(out)
            assert w < start + st['r'], 'trepitja el flux: escriu %d, llegit fins %d' % (w, start + st['r'])
        out.append(x)
    while True:
        if not getbit():
            put(rd())
            continue
        g = gamma()
        if g == 0:
            break
        L = g + 1
        h = gamma() - 1
        o = h * 256 + rd() + 1
        for _ in range(L):
            put(out[-o])
    return bytes(out), st['r']

def inplace(region, first=False):
    """region: bytes del desti. Tria el tall n: [0,n) va comprimit i acaba just a n; [n,fi)
    es la cua sense comprimir, que ha de comencar amb dos zeros. Torna (flux, n, inici)
    amb inici = on comenca el flux (el maxim lloc lliure al davant)."""
    best = None
    E = len(region)
    for n in range(E - 2, max(E - 200, 0), -1):
        if region[n] or region[n + 1]:
            continue
        c = encode(region[:n], inplace=True)
        st = n - len(c)
        if st < 0:
            continue
        try:
            out, r = decode(c, region[n:], base=0, start=st)
        except AssertionError:
            continue
        assert out == region[:n] and r <= len(c) + 2
        if best is None or st > best[0]:
            best = (st, c, n, st)
        if first:
            break
    if best is None:
        raise SystemExit('no es pot descomprimir al mateix lloc')
    return best[1], best[2], best[3]

if __name__ == '__main__':
    import sys
    d = open(sys.argv[1], 'rb').read()
    c = encode(d)
    assert decode(c)[0] == d
    print(len(d), '->', len(c))
