#!/usr/bin/env python3
"""VINTIUNA PRO - generador del joc de caracters i de les taules de cartes.
Escriu charset.bin (128 caracters per a $1c00) i cards.inc. build.py els comprimeix (els
64 a MIRDST-1 en un segment del flux, els 0-62 dins del bloc R; el 63 no es fa servir).
(el mateix joc comprimit, que es el que porta el PRG) i cards.inc (taules per a ACME).
Cal Python 3 i Pillow (pip install pillow). Despres: acme -f cbm -o vintiuna_pro.prg vintiuna_pro.asm
Per canviar un grafic, edita el dibuix corresponent d'aquest fitxer i torna'l a executar."""
import sys

# ================= caracters d'alta resolucio =================
from PIL import Image, ImageDraw
def g(rows):  # 8 files de 8 caracters -> matriu
    assert len(rows)==8 and all(len(r)==8 for r in rows), rows
    return [[1 if c=='#' else 0 for c in r] for r in rows]
def grid(art, cw, ch):  # art gran -> llista de glyphs per cel.la [fila][col]
    lines=[l.ljust(cw*8,'.') for l in art.strip('\n').split('\n')]
    assert len(lines)==ch*8, (len(lines), ch*8)
    return [[ [[1 if lines[r*8+y][c*8+x]=='#' else 0 for x in range(8)] for y in range(8)] for c in range(cw)] for r in range(ch)]

G = {}
# ---- marc de la carta (color verd = el tapet): cantonades arrodonides
G['TL']=g(['########','###.....','##......','#.......','#.......','#.......','#.......','#.......'])
G['TR']=g(['########','.....###','......##','.......#','........','........','........','........'])
G['BL']=g(['#.......','#.......','#.......','#.......','#.......','##......','###.....','########'])
G['BR']=g(['........','........','........','........','.......#','......##','.....###','########'])
# primera carta de la ma (i retols): sense linia a l'esquerra, la vora es el limit de la casella
G['TLF']=g(['########','###.....','##......','#.......','........','........','........','........'])
G['BLF']=g(['........','........','........','........','#.......','##......','###.....','########'])
G['T'] =g(['########','........','........','........','........','........','........','........'])
G['B'] =g(['........','........','........','........','........','........','........','########'])
G['L'] =g(['#.......']*8)
G['R'] =g(['.......#']*8)    # separador sobre la carta anterior, a la fila de l'index
G['FULL']=g(['########']*8)
G['FELT']=g(['########','########','###.####','########','########','#######.','########','########'])
G['RAIL']=g(['########','#..#..#.','.##.##.#','########','########','.#..#..#','#.##.##.','########'])
# ---- dors: trama de rombes
G['BACK']=g(['...##...','..#..#..','.#.##.#.','#.#..#.#','#.#..#.#','.#.##.#.','..#..#..','...##...'])
# ---- pals petits (5 pixels d'ample: amb el pixel ample del VIC queden proporcionats)
G['S']=g(['...#....','..###...','..###...','.#####..','.#####..','.#.#.#..','...#....','..###...'])
G['H']=g(['.##.##..','.#####..','.#####..','.#####..','..###...','..###...','...#....','........'])
G['D']=g(['...#....','..###...','..###...','.#####..','.#####..','..###...','..###...','...#....'])
G['C']=g(['..###...','..###...','...#....','.##.##..','.#####..','.##.##..','...#....','..###...'])
# ---- el 10 en una sola casella
G['10']=g(['.#..##..','##.#..#.','.#.#..#.','.#.#..#.','.#.#..#.','.#.#..#.','.#..##..','........'])

# ---- pals grans de l'as: 3x3 caselles, dibuixats en vectorial i reduits
def bigsuit(kind):
    S=8; W=24*S; im=Image.new('L',(W,W),0); d=ImageDraw.Draw(im)
    cx=W/2; sw=16*S/2  # mig ample (16 pixels) -> proporcionat amb el pixel ample
    def heart(y0,flip=False):
        r=sw/2.1
        pts=[]
        if not flip:
            d.ellipse([cx-sw,y0,cx,y0+2*r*1.25],fill=255); d.ellipse([cx,y0,cx+sw,y0+2*r*1.25],fill=255)
            d.polygon([(cx-sw+S*0.3,y0+r*1.5),(cx+sw-S*0.3,y0+r*1.5),(cx,W-2*S)],fill=255)
        else:
            d.ellipse([cx-sw,W-4*S-2*r*1.25,cx,W-4*S],fill=255); d.ellipse([cx,W-4*S-2*r*1.25,cx+sw,W-4*S],fill=255)
            d.polygon([(cx-sw+S*0.3,W-4*S-r*1.5),(cx+sw-S*0.3,W-4*S-r*1.5),(cx,1*S)],fill=255)
    if kind=='H': heart(2*S)
    if kind=='S':
        heart(0,flip=True)
        d.polygon([(cx-S*0.8,W-6*S),(cx+S*0.8,W-6*S),(cx+S*3.5,W-1*S),(cx-S*3.5,W-1*S)],fill=255)
    if kind=='D': d.polygon([(cx,1*S),(cx+sw*0.85,W/2),(cx,W-1*S),(cx-sw*0.85,W/2)],fill=255)
    if kind=='C':
        r=sw*0.47
        d.ellipse([cx-r,1*S,cx+r,1*S+2*r*1.3],fill=255)
        d.ellipse([cx-sw,8*S,cx-sw+2*r,8*S+2*r*1.3],fill=255)
        d.ellipse([cx+sw-2*r,8*S,cx+sw,8*S+2*r*1.3],fill=255)
        d.polygon([(cx-S*0.9,9*S),(cx+S*0.9,9*S),(cx+S*3.5,W-1*S),(cx-S*3.5,W-1*S)],fill=255)
    sm=im.resize((24,24),Image.BOX)
    px=[[1 if sm.getpixel((x,y))>110 else 0 for x in range(24)] for y in range(24)]
    return [[[ [px[r*8+y][c*8+x] for x in range(8)] for y in range(8)] for c in range(3)] for r in range(3)]
for k in 'SHDC': G['BIG'+k]=bigsuit(k)

# ================= multicolor: '.' fons, 'k' negre (vora), 'c' color de la casella, 'a' auxiliar (pell) =================
# Art multicolor: '.' fons (blanc), 'k' color de vora (negre), 'c' color de la casella, 'a' auxiliar (pell)
MCV = {'.':0,'k':1,'c':2,'a':3}
def mgrid(art, cw, ch):
    lines=[l for l in art.strip('\n').split('\n')]
    assert len(lines)==ch*8, (len(lines), ch*8)
    for l in lines: assert len(l)==cw*4, (len(l),l)
    return [[ [[MCV[lines[r*8+y][c*4+x]] for x in range(4)] for y in range(8)] for c in range(cw)] for r in range(ch)]
def mg(rows): return mgrid('\n'.join(rows),1,1)[0][0]

MC = {'RAIL': mg(['kkkk','aaaa','acaa','aaac','aaaa','caaa','aaca','kkkk']),
      # barana de baix: sense perfil negre inferior (el fa la vora de la pantalla)
      'RAILB':mg(['kkkk','aaaa','acaa','aaac','aaaa','caaa','aaca','aaaa'])}

# ================= figures J, Q, K (3x9 caselles) =================
def art(src):
    """6 caracters = meitat esquerra (es fa simetric); 12 = fila sencera"""
    out=[]
    for l in src.strip('\n').split('\n'):
        l=l.split()[0]
        if len(l)==6: l=l+l[::-1]
        assert len(l)==12,(l,len(l)); out.append(l)
    assert len(out)==72,len(out)
    return '\n'.join(out)

KING = art('''
......
..k..k
..kc.k
..kcck
..kccc
..kcac
..kccc
..kkkk
..kcac
..kkkk
.k.kaa
k..aaa
k..aaa
k..kka
k..aaa
k..aaa
k.a.ca
k.a.ca
k.aaaa
k.aaak
k.aaak
k.aaaa
k.aaaa
k..aaa
k..caa
k...aa
k.....
k...cc
k.....
k.....
k.....
k.....
.k....
.k....
.k....
..k...
..k...
..k...
...k..
...k..
cc..k.
ccc.k.
cck..k
ck.k..
c.k..k
ck.k..
cck...
ccck..
ccccck.ccaak
ccccc..cckak
ccccc.kccaak
ccccc..cccak
ccccck.cccak
ccccc..cccak
ccccc.kcccak
ccccc..cccak
ccccck.cccak
ccccc..cccak
ccccc.kcccak
ccccc..cccak
ccccck.cccak
ccccc..cccak
ccccc.kcccak
ccccc..cccak
ccccck.cccak
ccccc..cccak
ccccc.kcccak
ccccc..cccak
ccccck.ccccc
ccccc..ccccc
ccccc.kccccc
kkkkkk
''')
KING_C = [[7,7,7],[7,7,7],[6,6,6],[2,2,2],[2,2,2],[6,6,6],[6,6,6],[6,6,6],[6,6,6]]

QUEEN = art('''
......
...k.k
...kck
...kcc
...kac
...kcc
...kkk
..kkkk
.kkkaa
.kkaaa
.kaaaa
.kaaaa
.kakka
.kaaaa
.kaaaa
.kaaaa
.ka.ca
.ka.ca
.kaaaa
.kaaak
.kaaaa
.kaaaa
kkaaaa
kkaaaa
kkacaa
kkaaaa
kkaaac
kkkaaa
kkkkaa
kkkk.a
kkk..a
kkk.ka
kk.c.k
k.ccca
.cccc.
cccck.
ccc.c.
cccccc
kcc.cc
kkcccc
kkcccc
kccc.c
kccccc
cccccc
ccc.cc
cccccc
c.cccc
cccccc
ccc..c
cc.aa.
c.akka
cc.aa.
ccc..c
cccccc
cccc.k
ccc.kc
cccc.k
cccccc
c.cccc
cccccc
ccc.cc
cccccc
c.cccc
cccccc
ccc.cc
cccccc
c.cccc
cccccc
ccc.cc
c.c.c.c.c.c.
.c.c.c.c.c.c
kkkkkk
''')
QUEEN_C = [[7,7,7],[7,7,7],[6,6,6],[2,2,2],[4,4,4],[4,4,4],[4,4,4],[4,4,4],[4,4,4]]

JACK = art('''
.......aa...
....ccccaa..
...cccccca..
..cccccccc..
.ccccc
.ccccc
.ccccc
kkkkkk
..kcca
.ckaaa
.ckaaa
.ckaaa
.ckkka
.ckaaa
.ckaaa
.ckaaa
.kka.c
.kka.c
.kkaaa
.kkaak
.kkaak
.kkaaa
..kaaa
..kaaa
..kcaa
..kaaa
..kakk
...kaa
....ka
.....k
......
.....a
..kk.a
.k..k.
k.k..k
.k..k.
k.k..k
kckkck
cccccc
cccccc
ccccckaccccc
cccccakccccc
ccccckaccccc
cccccakccccc
ccccckaccccc
cccccakccccc
ccccckaccccc
cccccakccccc
ccccckaccccc
cccccakccccc
ccccckaccccc
cccccakccccc
kkkkkk
kkkkka
kkkkkk
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
cccccc
c.c.c.c.c.c.
.c.c.c.c.c.c
kkkkkk
''')
JACK_C = [[6,6,6],[7,7,7],[6,6,6],[2,2,2],[2,2,2],[2,2,2],[2,2,2],[2,2,2],[2,2,2]]

MCFACES2 = {'K':(mgrid(KING,3,9),KING_C), 'Q':(mgrid(QUEEN,3,9),QUEEN_C), 'J':(mgrid(JACK,3,9),JACK_C)}

# ---- dors: dibuix sencer de 40x104 pixels (marge blanc, marc i trellat de rombes amb punts)
CW, CH = 5, 13
def tile_dots():
    t=[[0]*8 for _ in range(8)]
    for i in range(8): t[i][i]=1; t[i][(8-i)%8]=1
    t[0][4]=t[4][0]=1; t[3][0]=t[5][0]=t[4][1]=t[4][7]=1
    return t
def back(tile, mx=2, my=2):
    W,H=CW*8,CH*8
    px=[[tile[y%8][x%8] for x in range(W)] for y in range(H)]
    for y in range(H):
        for x in range(W):
            m = x<mx or x>=W-mx or y<my or y>=H-my
            f = not m and (x==mx or x==W-1-mx or y==my or y==H-1-my)
            g = not m and not f and (x==mx+1 or x==W-2-mx or y==my+1 or y==H-2-my)
            px[y][x] = 0 if (m or g) else (1 if f else px[y][x])
    return [[[[px[r*8+y][q*8+x] for x in range(8)] for y in range(8)] for q in range(CW)] for r in range(CH)]

# ================= generacio =================

def hbytes(gl):  # alta resolucio 8x8 de 0/1
    return bytes(sum(b<<(7-x) for x,b in enumerate(row)) for row in gl)
def mbytes(gl):  # multicolor 4x8 de valors 0-3
    return bytes((r[0]<<6)|(r[1]<<4)|(r[2]<<2)|r[3] for r in gl)

# Lletres clau en invers (Doblar, Carta, Plantar-se, S/N, Y): van al codi de pantalla de la lletra
# (C=3, D=4, N=14, P=16, S=19, Y=25), aixi el programa nomes ha de treure el bit 7 a la lletra del missatge.
ROMKEY = {'C':'3C66606060663C00', 'D':'786C6666666C7800', 'P':'7C66667C60606000',   # ROM del VIC
          'S':'3C66603C06663C00', 'N':'66767E7E6E666600', 'Y':'6666663C18181800',
          'E':'7E60607860607E00'}
# C i N van a 64 i 65 (es descomprimeixen en arrencar: el menu de la presentacio les fa servir);
# la resta, al codi de pantalla de la lletra. Els textos les escriuen com a $80+caracter (K_x).
KEYSLOT = {'C':64, 'N':65, 'D':4, 'P':16, 'S':19, 'Y':25, 'E':5}
chars=[None]*128; index={}; nxt=[0]
chars[63]=bytes(8)      # lliure: el bloc R acaba abans (alli hi ha el final del flux comprimit)
for ch,h in ROMKEY.items():
    chars[KEYSLOT[ch]] = bytes(255-int(h[i*2:i*2+2],16) for i in range(8))
def add(name, data, unique=True):
    if data in index and unique: code=index[data]
    else:
        while chars[nxt[0]] is not None: nxt[0]+=1
        code=nxt[0]; chars[code]=data; index.setdefault(data,code)
    if name: names[name]=code
    return code
names={}
add('C_BLANK', bytes(8))
add('C_FELT',  hbytes(G['FULL']))
for k in ['TL','TR','BL','BR','T','B','L']: add('C_'+k, hbytes(G[k]), unique=False)
k=next(k for k in range(128) if all(chars[k+i] is None for i in range(4)))   # 4 seguits (C_SUIT0+pal)
for i,s in enumerate('SHCD'):   # 0 piques 1 cors 2 trebols 3 diamants
    chars[k+i]=hbytes(G[s]); names['C_SUIT%d'%i]=k+i
add('C_TEN', hbytes(G['10']), unique=False)
add('C_RAIL', mbytes(MC['RAIL']), unique=False)
add('C_RAILB', mbytes(MC['RAILB']), unique=False)
for k in ['TLF','BLF']: add('C_'+k, hbytes(G[k]), unique=False)
add('C_SEP', hbytes(G['R']), unique=False)
bk=back(tile_dots())
for nm,(r,c) in zip(['BTL','BT','BTR','BL_','BI','BR_','BBL','BB','BBR'],[(0,0),(0,1),(0,4),(1,0),(1,1),(1,4),(12,0),(12,1),(12,4)]):
    add('C_'+nm, hbytes(bk[r][c]), unique=False)
big=[]
for s in 'SHCD':
    g=G['BIG'+s]
    for r in range(3):
        for c in range(3): big.append(add(None, hbytes(g[r][c])))
faces=[]; facecol=[]
for f in 'JQK':
    art,cc=MCFACES2[f]
    for r in range(9):
        for c in range(3): faces.append(add(None, mbytes(art[r][c])))
        assert cc[r][0]==cc[r][1]==cc[r][2]
        c=cc[r][0]
        facecol.append(8+c+(0x10 if (r>=4 and c in (2,4,6)) else 0))   # $10: roba del color del pal
assert [names['C_SUIT%d'%i] for i in range(4)]==list(range(names['C_SUIT0'],names['C_SUIT0']+4))
n=sum(c is not None for c in chars)
print('caracters propis:', n, 'de 128')

# ================= miralls =================
# Els caracters que son el mirall d'un altre no van al PRG: l'arrencada els genera.
# Els originals queden seguits a MIRSRC.. i els miralls a MIRDST..; primer els d'alta
# resolucio (mirall = bits a l'inreves) i despres els multicolor (parelles a l'inreves).
def mir_h(b): return int('{:08b}'.format(b)[::-1],2)
def mir_m(b): return ((b&3)<<6)|((b&12)<<2)|((b&48)>>2)|((b&192)>>6)
MCSET=set(faces)|{names['C_RAIL'],names['C_RAILB']}
pairs=[]; seen=set()
for i in range(128):
    if chars[i] is None or chars[i]==bytes(8) or i in seen: continue
    mc=i in MCSET; m=bytes((mir_m if mc else mir_h)(b) for b in chars[i])
    if m==chars[i]: continue
    for j in range(i+1,128):
        if j not in seen and chars[j]==m and (j in MCSET)==mc:
            pairs.append((i,j,mc)); seen|={i,j}; break
pairs.sort(key=lambda t:t[2])                  # alta resolucio primer
NMIR=len(pairs); NMIRH=sum(1 for t in pairs if not t[2])
MIRDST=n-NMIR; MIRSRC=MIRDST-NMIR             # els miralls, al final dels caracters usats
assert MIRSRC>=64 and MIRDST+NMIR<=128 and all(c is not None for c in chars[:n])
target={}
for k,(a,b,mc) in enumerate(pairs): target[a]=MIRSRC+k; target[b]=MIRDST+k
vacant=sorted(set(target)-set(target.values())); displaced=sorted(set(target.values())-set(target))
assert len(vacant)==len(displaced)
perm={i:i for i in range(128)}; perm.update(target); perm.update(dict(zip(displaced,vacant)))
assert sorted(perm.values())==list(range(128))
newc=[None]*128
for i in range(128): newc[perm[i]]=chars[i]
chars=newc
names={k:perm[v] for k,v in names.items()}
big=[perm[c] for c in big]; faces=[perm[c] for c in faces]
for k,(a,b,mc) in enumerate(pairs):
    assert chars[MIRDST+k]==bytes((mir_m if mc else mir_h)(x) for x in chars[MIRSRC+k])
print('miralls generats a l\'arrencada: %d (%d d\'alta resolucio)'%(NMIR,NMIRH))
open('charset.bin','wb').write(b''.join(c or bytes(8) for c in chars))

full=b''.join(c or bytes(8) for c in chars)

# pips: 7 files (files 3..9 de la carta), tipus 0 centre, 1 res, 2 parella
PIPS9 = {2:[(1,'C'),(7,'C')], 3:[(1,'C'),(4,'C'),(7,'C')], 4:[(1,'P'),(7,'P')],
         5:[(1,'P'),(4,'C'),(7,'P')], 6:[(1,'P'),(4,'P'),(7,'P')],
         7:[(1,'P'),(2,'C'),(4,'P'),(7,'P')], 8:[(1,'P'),(2,'C'),(4,'P'),(6,'C'),(7,'P')],
         9:[(1,'P'),(3,'P'),(4,'C'),(5,'P'),(7,'P')], 10:[(1,'P'),(2,'C'),(3,'P'),(5,'P'),(6,'C'),(7,'P')]}
pip=[]
for k in range(2,11):
    t=[1]*7
    for r,ty in PIPS9[k]: t[r-1]={'C':0,'P':2}[ty]
    v=0
    for i,x in enumerate(t): v|=x<<(14-2*i)
    pip+= [v&255, v>>8]
ROMC={'A':1,'J':10,'Q':17,'K':11}
rank=[]
for r in range(1,14):
    if r==10: rank.append(names['C_TEN'])
    elif r in (1,11,12,13): rank.append(0x80|ROMC['AJQK'[[1,11,12,13].index(r)]])
    else: rank.append(0x80|(0x30+r))
L=[]
L.append('; ---- generat per genera_caracters.py: no editar a ma ----')
for k,v in names.items(): L.append('%-8s = %d' % (k,v))
for k,v in KEYSLOT.items(): L.append('K_%-6s = %d          ; lletra clau en invers' % (k,v))
def row(lbl, data, per=18):
    out=[]
    for i in range(0,len(data),per):
        out.append(('%-9s' % (lbl if i==0 else ''))+'!byte '+','.join('$%02x'%d for d in data[i:i+per]))
    return out
L+=row('rankch',rank)
L.append('cardtab  = bigtab')
L+=row('bigtab',big)
L+=row('facetab',faces,27)
L+=row('facecol',facecol,9)
L+=row('pipdat',pip)
L.append('PROB     = $%04x          ; probabilitats del descompressor (despres hi van els miralls)' % (0x1c00+MIRDST*8))
L.append('MIRSRC   = %d          ; caracters originals dels miralls' % MIRSRC)
L.append('MIRDST   = %d          ; miralls (els genera l\'arrencada)' % MIRDST)
L.append('NMIR     = %d' % NMIR)
L.append('NMIRH    = %d          ; els primers, d\'alta resolucio; la resta multicolor' % NMIRH)
open('cards.inc','w').write('\n'.join(L)+'\n')

