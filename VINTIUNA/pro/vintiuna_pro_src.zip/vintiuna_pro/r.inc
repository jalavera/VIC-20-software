; ---- generat per build.py: no editar a ma ----
SLEN    = 3008          ; flux comprimit
