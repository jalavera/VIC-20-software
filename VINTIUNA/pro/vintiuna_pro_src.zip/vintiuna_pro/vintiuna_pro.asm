; =============================================================
;  VINTIUNA PRO  -  VIC-20 sense expansio, PAL
;  Cartes amb caracters propis i multicolor, les dues mans a la vista
;  Assemblar:  python3 build.py   (assembla amb ACME dues vegades: la primera per fer el
;              flux comprimit; necessita textos.inc, cards.inc, charset.bin i blz2.py)
;  Textos:     python3 genera_textos.py  torna a generar textos.inc (despres de cards.inc)
;  Grafics:    python3 genera_caracters.py  torna a generar charset.bin i cards.inc; nomes
;              cal si es canvien els dibuixos
;  Memoria:    al PRG, a dalt el descompressor i la presentacio; de $1200 a $1dff, el flux
;              comprimit (blz2.py, aritmetic). En arrencar es descomprimeix tot: caracters
;              64-97 a $1e00, ruina i credits al buffer del cassette ($033c), parelles dels
;              textos i registres del VIC al fons de la pila ($0100), soroll del remenat al
;              buffer del BASIC ($0234), i el bloc R al mateix lloc: final de l'arrencada,
;              musica, programa i caracters 0-62 ($1200-$1df7). Pantalla $1000 (28x35).
;  Llengua:    menu a la presentacio (C catala, N angles); cada text porta les dues versions
; =============================================================
!cpu 6502

; ---------- memoria ----------
SCREEN  = $1000         ; pantalla 28x35 (980 bytes): omple tota la imatge PAL
COLRAM  = $9400
CHARSET = $1c00         ; caracters 0-127 propis; 128-255 = ROM (textos)
DECK    = $0200         ; baralla (52), al buffer d'entrada del BASIC
EXTRA   = $033c         ; buffer del cassette (192 bytes): codi que l'arrencada hi copia
EXTRA2  = DECK+52       ; resta del buffer del BASIC ($0234-$0258, 37 bytes): mes codi
EXTRA3  = $02a1         ; $02a1-$02ff, lliure al VIC-20: estrelles dels credits
LOW     = $0100         ; fons de la pila: parelles dels textos i registres del VIC
RSTART  = $1200         ; bloc R (comprimit al PRG): $1200-$1df7
RDUMMY  = $4000         ; on l'assembla build.py per comprimir-lo
WIDTH   = 28
HEIGHT  = 35

; ---------- disposicio ----------
MROW    = 0             ; files de missatges 0-2, barana a la 3, tapet 4-33, barana a la 34
RAILROW = 3
BOTROW  = HEIGHT-1
CARDH   = 13            ; carta de 5x13
FAN0    = 10            ; columna de la primera carta (pas de 3)
ROWBANK = 5             ; fila de les cartes de la banca
ROWPLAY = 20            ; fila de les cartes del jugador
PILEC   = 11            ; columna i fila de la pila en remenar
STOP    = 12
PLQCOL  = 2             ; retols a l'esquerra de cada ma

; ---------- sistema ----------
JIFFY   = $a2
NKEYS   = $c6
SHFLAG  = $0291
GETIN   = $ffe4
VOICE_L = $900a
VOICE_M = $900b
VOICE_H = $900c
VOICE_N = $900d
VOLUME  = $900e

BLACK=0 : WHITE=1 : RED=2 : PURPLE=4 : GREEN=5 : BLUE=6 : MC=8

; ---------- temps, en unitats de 2 jiffies (1/30 s) ----------
D_TYPE  = 1
D_CLAC  = 1
D_CRED  = 150           ; credits: 5 s amb el text complet, i reinici
D_CARD  = 10
D_BANK  = 40
D_MSG   = 90

; ---------- capcalera de missatge (1 byte) ----------
; bit 0 = segueix un byte de columna, bits 1-2 color (coltab), bits 3-7 fila
C_RED=0 : C_PUR=2 : C_GRN=4 : C_BLU=6 : HCOL=1
SEP     = $fe           ; separa el text catala de l'angles
!macro hdr .row, .col { !byte (.row<<3)|.col }
!source "textos.inc"    ; textos comprimits (+t_nom): python3 genera_textos.py

; ---------- pagina zero ----------
sp      = $10           ; punter pantalla (2)
cp      = $12           ; punter color (2)
cx      = $14
curcol  = $15
mptr    = $16           ; (2)
rng     = $18           ; (2)
num     = $1a           ; (2)
mu      = $1c           ; fitxes (2)
be      = $1e           ; aposta (2)
tu      = $20           ; -. a 0 cada torn
nu      = $21           ;  |
t2      = $22           ; -'
tb      = $23           ; -. a 0 cada ma (2)
eb      = $25           ;  |
gg      = $26           ;  |
pl      = $27           ; -'  0 jugador, 1 banca
best    = $28
yy      = $29
tcol    = $2a
rank    = $2b
ccol    = $2c
key     = $2d           ; caracter del pal
tmp     = $2e
cnt     = $2f
tbase   = $30
sidx    = $31
candbl  = $32
z       = $33
pat     = $34           ; (2)
mask    = $36
crow    = $37           ; fila de les cartes d'aquest torn
robe    = $38           ; color de la roba de les figures (segons el pal)
tmp2    = $39
bw      = $3a           ; amplada del mig de les capses
nz      = $3b           ; generador de soroll del remenat (no toca rng: la baralla no canvia)
spd     = $3c           ; velocitat de la carta que llisca
zd      = $3d           ; (2) descompressor: desti
zs      = $3f           ; (2) descompressor: font de la repeticio
gch     = $41           ; presentacio: acord x 4
mrem    = $42           ; presentacio: cicles que queden de la nota
gt      = $43           ; presentacio: cicle dins la unitat (0-2)
gu      = $44           ; presentacio: unitat dins el compas (0-7)
lang    = $45           ; llengua: 0 catala, 1 angles
sk      = $46           ; pmsg: quants textos cal saltar abans d'escriure
bits    = $47           ; descompressor: bits que queden del byte (amb sentinella)
gv      = $48           ; descompressor: valor gamma
arng    = $49           ; (2) descompressor: amplada de l'interval
acod    = $4b           ; (2) descompressor: valor dins l'interval
ma      = $4d           ; descompressor: multiplicacio
db      = $4e           ; descompressor: arbre de 8 bits (base, mascara, cami)
dm      = $4f
dc      = $50
alen    = $51           ; descompressor: longitud
LENB = 2 : HIB = 18 : LOB = 34 : LITB = 66 : NCTX = 194   ; contextos (blz2.py)

; =============================================================
;  $1001: arrencada. Aquesta zona despres es la pantalla.
;  El PRG va de $1001 a $1dff: no toca la pantalla del BASIC ($1e00).
; =============================================================
        * = $1001
        !word +, 10
        !byte $9e
        !text "4109"
        !byte 0
+       !word 0
        jmp boot1               ; (al bloc R, abans de descomprimir-lo)

; =============================================================
;  PRESENTACIO: nomes en arrencar (aquesta zona despres es la pantalla)
;  Musica: Guillem Tell (Rossini, 1829), obertura, el Galop: primera seccio
;  (8 compassos) i segona (16), en Sol major. Melodia a la veu aguda; "oom-pah"
;  a pulsacio fixa: baix (fonamental i quinta) a la veu greu als temps, acord a
;  la veu mitjana i cop de soroll als contratemps. Acords amb setena on toca.
;  Es repeteix fins que es prem una tecla.
;  Mapa durant la presentacio: a dalt (files 0-10), aquest codi; al mig, el text; a
;  baix (BOTTOM), el reproductor i la tonada.
; =============================================================
ITITLE  = 11                    ; files del text (entre el codi viu de dalt i el de baix)
IPROMPT = 22
UNIT    = 3                     ; corxera de la transcripcio = 3 x 2 jiffies (0,1 s)

intro   ldx #Q4                 ; tot el color en blanc: les restes de l'arrencada
        lda #WHITE              ; que hi ha a la pantalla no es veuen
-       sta COLRAM-1,x
        sta COLRAM-1+Q4,x
        sta COLRAM-1+2*Q4,x
        sta COLRAM-1+3*Q4,x
        dex
        bne -
        jsr pmsg
        +hdr ITITLE, C_RED|HCOL
        !byte (WIDTH-12)/2
        +t_titol
        jsr pmsg                ; i el nom en angles
        +hdr ITITLE+1, C_BLU|HCOL
        !byte (WIDTH-11)/2
        +t_titolen
        ldx #ITITLE+3           ; "(c)jimsoft 2026" dels credits, en el mateix color
        jsr jimsoft
        jsr pmsg                ; llengua (a la fila de la primera regla, que la tapa)
        +hdr ITITLE+5, C_PUR|HCOL
        !byte (WIDTH-17)/2
        +t_menu
-       jsr getkey
        cmp #'C'
        beq +
        cmp #'E'
        bne -
        inc lang                ; angles
+       jsr pmsg                ; instruccions
        +hdr ITITLE+5, C_GRN|HCOL
        !byte (WIDTH-20)/2
        +t_regla1
        jsr pmsg
        +hdr ITITLE+6, C_GRN|HCOL
        !byte (WIDTH-22)/2
        +t_regla2
        jsr instr2              ; (al fons de la pila)
        jmp intro2              ; (a la fila 21)

toplive_end
!if toplive_end > SCREEN+ITITLE*WIDTH+(WIDTH-12)/2 { !error "el text de la presentacio trepitja el codi de dalt" }

; ---- a partir d'aqui, nomes es fa servir en arrencar (despres hi va el text)
; ---- descompressor aritmetic (format a blz2.py): A/X = flux. El flux te segments:
;      adreca de desti i dades; adreca 0 = fi. Probabilitats a PROB (on despres van els
;      miralls). Mentre treballa, la vora fa colors.
unpack  sta mptr
        stx mptr+1
        ldy #0
        sty bits                ; sense bits: el primer getbit llegeix un byte
        lda #$80                ; totes les probabilitats a 1/2
        ldx #NCTX
-       sta PROB-1,x
        dex
        bne -
        dex                     ; rng = $ffff
        stx arng
        stx arng+1
        ldx #16                 ; cod = els 16 primers bits
-       jsr getbit
        rol acod
        rol acod+1
        dex
        bne -
up_seg  jsr declit              ; segment: adreca de desti (part alta 0 = fi)
        sta zd
        jsr declit
        sta zd+1
        beq up_end
up_l0   ldx #0                  ; (context: darrere d'un literal)
up_lp   jsr decbit              ; tipus de token (context X: el tipus de l'anterior)
        bcs up_rep
        jsr declit              ; 0: literal
        jsr put
        bcs up_l0               ; (C=1)
up_rep  ldx #LENB               ; 1: repeticio. Longitud-1 (0 = fi del segment)
        jsr gamma
        beq up_seg
        sta alen
        ldx #HIB                ; part alta de la distancia + 1
        jsr gamma
        dec gv
        ldx #LOB                ; part baixa: zs = zd - distancia
        lda #31
        jsr dec8
        clc
        eor #$ff
        adc zd
        sta zs
        lda gv
        eor #$ff
        adc zd+1
        sta zs+1
        ldx alen
        inx
-       ldy #0
        lda (zs),y
        jsr put
        inc zs
        bne +
        inc zs+1
+       dex
        bne -
        inx                     ; (X=1: darrere d'una repeticio)
        bne up_lp
gamma   lda #1                  ; gamma: per cada bit, "continuar" (context X) i el bit
        sta gv                  ; (X+1); 1 = fi. Torna A = valor, 0 si passa de 255 (fi)
-       jsr decbit
        bcs +
        inx
        jsr decbit
        rol gv
        inx
        bcc -
+       lda gv
up_end  rts
declit  ldx #LITB               ; un literal (o mig adreca de desti)
        lda #127
dec8    stx db                  ; 8 bits en arbre: context X + (c AND A). Torna A, C=1
        sta dm
        lda #1
-       sta dc
        and dm
        clc
        adc db
        tax
        jsr decbit
        lda dc
        rol
        bcc -
        rts
decbit  lda PROB,x              ; un bit amb probabilitat p/256 (context X). Torna C
        lsr                     ; b8 = rng/256 * (p/8) / 32 (5 bits de p: 5 voltes)
        lsr
        lsr
        sta ma
        lda #0
        ldy #5
-       lsr ma
        bcc +
        clc
        adc arng+1
+       ror
        dey
        bne -
        sta ma
        lda acod+1
        cmp ma
        bcc db_1                ; cod < b8*256: bit 1
        sbc ma                  ; bit 0: cod i rng - b8*256, p - p/16
        sta acod+1
        lda arng+1
        sbc ma
        sta arng+1
        lda PROB,x
        lsr
        lsr
        lsr
        lsr
        eor #$ff
        sec
        adc PROB,x
        clc
        bcc db_n
db_1    lda ma                  ; bit 1: rng = b8*256, p + (255-p)/16
        sta arng+1
        sty arng                ; (Y=0)
        lda PROB,x
        eor #$ff
        lsr
        lsr
        lsr
        lsr
        clc
        adc PROB,x
        sec
db_n    sta PROB,x
        php
-       bit arng+1              ; mentre rng < $8000: rng*2, cod*2 + bit seguent
        bmi +
        asl arng
        rol arng+1
        jsr getbit
        rol acod
        rol acod+1
        bcc -                   ; (C=0: cod < rng)
+       plp
        rts
getbit  asl bits                ; C = bit seguent del flux
        bne +
        ldy #0                  ; byte nou: el bit 7 surt ara, i entra la sentinella
        lda (mptr),y
        inc mptr
        bne ++
        inc mptr+1
++      sec
        rol
        sta bits
+       rts
put     ldy #0
        sta (zd),y
        and #7                  ; vora de colors (fons negre)
        ora #8
        sta $900f
        inc zd
        bne +
        inc zd+1                ; pagina nova: compte enrere (bloc R, pagines $12-$1d: 6..0)
        lda #$1e
        sec
        sbc zd+1
        cmp #13
        bcs +
        lsr
        ora #$30                ; xifra
        sta $0200+2*13+6
        sec                     ; (el literal torna amb C=1)
+       rts
initxt  !scr "inicialitzant initializing      6      "
top_end
!if top_end > RSTART { !error "la zona de dalt trepitja el bloc R" }

; =============================================================
;  $1200 (PRG): el que nomes cal abans de descomprimir el bloc R, que despres ho trepitja
; =============================================================
        * = RSTART
boot1   lda #$80
        sta SHFLAG              ; no deixar canviar a minuscules
        lda #3                  ; amplada del mig de les capses (carta de 5)
        sta bw
        ldx #5                  ; finestra de 13x3 caracters de la ROM, amb la pantalla a
-       lda vinit,x             ; $0200 (buffer del BASIC) i el color a $9600: "inicialitzant"
        sta $9000,x             ; mentre la vora fa colors
        dex
        bpl -
        ldx #38
-       lda initxt,x
        sta $0200,x
        lda #WHITE
        sta $9600,x
        dex
        bpl -
        lda #>(boot2-1)         ; tot al seu lloc (el bloc R trepitja aixo); despres, boot2
        pha
        lda #<(boot2-1)
        pha
        lda #<stream
        ldx #>stream
        jmp unpack
vinit   !byte 6+15,$0f+62,$80+13,3*2,0,$80      ; centrada; pantalla $0200, caracters $8000
dead_end

; =============================================================
;  BLOC R: final de l'arrencada, musica, programa i caracters 0-62, de RSTART a $1df7.
;  Al PRG va comprimit (rstream), al final de la mateixa zona: es descomprimeix al mateix
;  lloc. build.py l'assembla a RDUMMY, el comprimeix i el treu del PRG.
; =============================================================
!source "r.inc"                 ; SLEN (l'escriu build.py)
        * = $1e00-SLEN
stream  !bin "r.blz2"           ; flux comprimit: caracters 64-97, blocs de memoria baixa i
                                ; el bloc R. Acaba a $1dff, despres del final del bloc R
                                ; ($1df7): alli hi ha la marca de fi, que es llegeix despres
                                ; d'escriure
!if dead_end > stream { !error "l'arrencada trepitja el flux comprimit" }

        * = RDUMMY
!pseudopc RSTART {
r_start
; ---- final de l'arrencada (despres el text de la presentacio ho trepitja)
; ---- caracters mirall: MIRDST+k = mirall de MIRSRC+k. Els NMIRH primers son d'alta
;      resolucio (bits a l'inreves); la resta, multicolor (parelles de bits a l'inreves)
boot2   ldy #NMIR*8             ; caracters mirall (a sobre de les probabilitats)
mr_lp   lda CHARSET+MIRSRC*8-1,y
        cpy #NMIRH*8+1
        bcc +
        sta tmp                 ; multicolor: primer intercanvia els bits de cada parella
        and #$55
        asl
        sta tmp2
        lda tmp
        lsr
        and #$55
        ora tmp2
+       sta tmp                 ; 8 bits a l'inreves (l'1 de sentinella surt al final)
        lda #1
-       lsr tmp
        rol
        bcc -
        sta CHARSET+MIRDST*8-1,y
        dey
        bne mr_lp               ; (Y=0)
        jmp boot3
        !fill SCREEN+20*WIDTH-*, 0
; ---- final de la presentacio (viu: a la fila 21, que la presentacio no fa servir)
gend    lda #0                  ; silenci i volum normal
        sta VOICE_L
        sta VOICE_M
        sta VOICE_N
        sta VOICE_H
        lda #$95
        sta VOLUME
        lda $9124               ; l'instant de la tecla barreja la llavor de l'atzar
        sta rng
        jmp shuffle
intro2  jsr pmsg
        +hdr IPROMPT, C_PUR|HCOL
        !byte (WIDTH-14)/2
        +t_premuna
        jmp gloop
gend_end
boot3   sty mu+1                ; 100 fitxes
        ldx #51                 ; baralla ordenada (al buffer del BASIC, on hi havia el
-       txa                     ; missatge de l'arrencada)
        sta DECK,x
        dex
        bpl -
        sty lang                ; catala, fins que es tria
        ldx #15                 ; registres del VIC: pantalla a $1000,
-       lda vicini,x            ; caracters a $1c00, 28x35, colors i so
        sta $9000,x
        dex
        bpl -
        lda $9124               ; llavor: temporitzador de la VIA
        sta rng
        lda $9125
        ora #1
        sta rng+1
        sta nz
        lda #100
        sta mu
        jmp intro
!if gend < SCREEN+20*WIDTH { !error "gend massa amunt", gend }
!if gend_end > SCREEN+IPROMPT*WIDTH { !error "gend ha d'anar a les files 20-21" }
BOTSIZE = 323                   ; mida del bloc de baix (si canvia, l'assemblador ho diu)
BOTTOM  = SCREEN+WIDTH*HEIGHT-BOTSIZE
        !fill BOTTOM-*, 0       ; (pantalla de la presentacio: text)

; =============================================================
;  Presentacio, a baix: reproductor i tonada (viu durant la presentacio)
; =============================================================
!source "musica.inc"    ; reproductor i tonada (tambe el fa servir musica_prova.asm)
bottom_end
!if TUNELEN > 255 { !error "la tonada ha de tenir menys de 256 bytes" }
!if bottom_end != SCREEN+WIDTH*HEIGHT { !error "BOTSIZE ha de ser la mida del bloc de baix", bottom_end-BOTTOM }
!if SCREEN+(IPROMPT+1)*WIDTH > BOTTOM { !error "el text de la presentacio trepitja el codi de baix" }

; =============================================================
;  $13d4: programa (i un bloc al buffer del cassette, vegeu extra_src)
; =============================================================
; ---------- remenat: les cartes llisquen cap a la pila ----------
shuffle jsr table
        inx                     ; (X=$ff)
        stx sidx
        jsr pmsg                ; (el titol ja surt a la presentacio)
        +hdr MROW+1, C_PUR|HCOL
        !byte (WIDTH-12)/2
        +t_barrejant
        lda #PILEC
        sta tcol
        jsr draw_back
shuf_lp jsr rnd                 ; deck(sidx) <-> deck(0..51 a l'atzar)
        and #$3f
        cmp #52
        bcs shuf_lp
        tay
        ldx sidx
        lda DECK,x
        pha
        lda DECK,y
        sta DECK,x
        pla
        sta DECK,y
        inc sidx
        lda sidx                ; dues barreges per carta que llisca
        lsr
        bcs shuf_lp
        jsr noise               ; d'on ve: banda i distancia (1-8 columnes) a l'atzar
        and #$0f                ; bit 3 = banda, bits 0-2 = distancia-1
        cmp #8
        and #7
        bcs +
        adc #PILEC+1            ; dreta: PILEC+d (C=0)
        bne ++                  ; (sempre)
+       eor #$ff                ; esquerra: PILEC-d (C=1)
        adc #PILEC-1
++      sta tcol
        jsr noise               ; velocitat: 1 o 2 unitats per columna
        and #1
        tax
        inx
        stx spd
slide   jsr draw_back
        jsr rustle              ; so i espera d'aquest pas
        lda tcol                ; esborrar la columna del darrere i avancar
        cmp #PILEC
        beq landed
        bcs +
        jsr clrcol              ; cap a la dreta: columna tcol
        inc tcol
        bne slide               ; (sempre)
+       adc #3                  ; cap a l'esquerra: columna tcol+4 (C=1)
        jsr clrcol
        dec tcol
        bne slide               ; (sempre)
landed  lda #$f8                ; "clac"
        sta VOICE_N
        lda #$90+12             ; volum 12 sense canviar l'auxiliar (si no, la barana parpelleja)
        sta VOLUME
        ldx #D_CLAC
        jsr delay               ; (torna amb X=0)
        stx VOICE_N
        lda #$90+5              ; volum 5 (i auxiliar taronja clar)
        sta VOLUME
        jsr noise               ; pausa curta i variable, en silenci
        and #3
        tax
        inx
        jsr delay               ; (torna amb X=0)
        lda sidx
        cmp #52
        beq +
        jmp shuf_lp
+       stx z
newhand lda z                   ; remenar quan queda un terc de baralla
        cmp #37
        bcc round
        jmp shuffle

; ---------- nova ma: tapet i retols ----------
round   jsr table
        lda #5                  ; retols de 7 caselles
        sta bw
        lda #PLQCOL
        sta tcol
        ldx #ROWBANK+4
        jsr plaque
        ldx #ROWPLAY+4
        jsr plaque
        lda #3                  ; cartes de 5 caselles
        sta bw
        jsr pmsg
        +hdr ROWBANK+5, C_BLU|HCOL
        !byte PLQCOL+1
        +t_banca
        jsr pmsg
        +hdr ROWPLAY+5, C_BLU|HCOL
        !byte PLQCOL+2
        +t_tu
        ldx #pl-tu              ; nova ma: a 0 de tu a pl
        !byte $2c               ; (BIT abs: salta el LDX seguent)
; ---------- nou torn ----------
turn    ldx #t2-tu              ; nou torn: a 0 de tu a t2
        lda #0
-       sta tu,x
        dex
        bpl -
        lda #FAN0-3
        sta tcol
        lda #ROWPLAY
        ldx pl
        beq +
        lda #ROWBANK
+       sta crow

; ---------- repartir una carta ----------
deal    inc nu
        ldx z                   ; (z <= 46: es remena abans d'acabar la baralla)
        lda DECK,x
        inx
        stx z
        ldx #0                  ; pal = carta/13, valor = resta+1
-       cmp #13
        bcc +
        sbc #13
        inx
        bne -
+       adc #1                  ; (C=0)
        sta rank
        txa                     ; cors i diamants (1, 3) en vermell
        and #1
        asl
        sta ccol
        lda robetab,x
        sta robe
        txa                     ; (C=0 de l'ASL)
        adc #C_SUIT0
        sta key
        lda sofs,x              ; inici del pal gran de l'as
        sta tmp2
        inc tcol
        inc tcol
        inc tcol
        jsr clr_top
        lda #GREEN              ; ---- dibuixar la carta
        sta curcol
        ldy #tmplf-tmpl         ; la primera, sense linia a l'esquerra
        lda nu
        lsr
        beq +
        ldy tcol                ; les altres: a la fila de l'index la linia va sobre
        dey                     ; la carta anterior (alli sempre hi ha blanc)
        ldx crow
        inx
        jsr setcur
        lda #C_SEP
        jsr putc_nc
        ldy #0                  ; i la resta, amb linia que la separa de l'anterior
+       ldx crow
        jsr drawbox_c
        lda ccol
        sta curcol
        ldy tcol                ; index de dalt: valor i pal, a la cantonada
        ldx crow
        inx
        jsr setcur
        jsr prank
        lda key
        jsr putc
        ldx rank                ; zona central
        dex
        dex
        cpx #9
        bcs face
        txa                     ; pips: 2 bits per fila (7 files)
        asl
        tax
        lda pipdat,x
        sta pat
        lda pipdat+1,x
        sta pat+1
        ldx crow
        inx
        inx
        inx
        ldy tcol
        iny
        jsr setcur
        lda #7
        sta cnt
prow    lda #0
        asl pat
        rol pat+1
        rol
        asl pat
        rol pat+1
        rol
        tay
        lda rowmask,y
        sta mask
        ldx #3
-       lda #C_BLANK
        lsr mask
        bcc +
        lda key
+       jsr putc
        dex
        bne -
        jsr rowend
        bne prow
        beq cardok
face    inx                     ; A (X=$ff) J Q K (X=9..11)
        bne +
        lda tmp2                ; as: pal gran 3x3 a la fila 5
        sta tmp
        lda #$ff
        sta tmp2
        lda #3
        ldx #5
        bne ++
+       lda fofs-10,x           ; figura 3x9 a la fila 2
        sta tmp
        lda sofs-10,x
        sta tmp2
        lda #9
        ldx #2
++      sta cnt
        txa
        clc
        adc crow
        tax
        jsr blk3
cardok  lda crow                ; index de baix: pal i valor, a la cantonada
        clc
        adc #CARDH-2
        tax
        ldy tcol
        iny
        iny
        iny
        jsr setcur
        lda ccol
        sta curcol
        lda key
        jsr putc
        jsr prank
        ldx #D_CARD
        jsr delay
        lda rank                ; sumar: figures = 10
        cmp #10
        bcc +
        lda #9                  ; (+C)
+       adc tu
        sta tu
        ldx rank
        dex
        bne +
        inc t2
+       lda tu                  ; l'as pot valer 11?
        sta best
        ldx t2
        beq +
        cmp #12
        bcs +
        adc #10                 ; (C=0)
        sta best
+       lda crow                ; puntuacio al retol: "17", o "7/17" si l'as pot valer 11
        clc
        adc #6
        tax
        ldy #PLQCOL+1
        jsr setcur
        lda #BLACK              ; (BLACK = C_BLANK = 0: putc torna A = curcol = 0)
        sta curcol
        ldx #5                  ; esborrar el valor anterior
-       jsr putc
        dex
        bne -
        ldy #PLQCOL+2
        lda best
        cmp tu
        beq +
        dey
        sty cx
        lda tu
        jsr pbyte
        lda #$af                ; "/"
        jsr tputc
        !byte $2c               ; (BIT abs: salta l'STY)
+       sty cx
        lda best
        jsr pbyte
        ; ---- jugades especials
        lda best
        cmp #21
        bne +
        ldx nu
        cpx #2
        bne +
        lda #30
        sta best
        jsr pmsg
        +hdr MROW+1, C_RED
        +t_natural
+       lda tu
        cmp #22
        bcc +
        lda #0
        sta best
        ldx pl
        bne bbust
        jsr pmsg
        +hdr MROW+1, C_RED
        +t_passat
bbust   jsr pmsg
        +hdr MROW+1, C_RED
        +t_bpassat
+       ldx nu
        cpx #5
        bne +
        lda #25
        sta best
        jsr pmsg
        +hdr MROW+1, C_RED
        +t_cinc
+       lda tu
        cmp #21
        bne no21
        ldx pl
        bne b21
        jsr pmsg
        +hdr MROW+1, C_RED
        +t_tens21
b21     jsr pmsg
        +hdr MROW+1, C_RED
        +t_bfa21
no21    ldx pl
        bne bank
        ldx nu
        dex
        bne options
        jmp bet

        ; ---- la banca demana fins a 17
bank    lda best
        cmp #17
        bcs +
        ldx #D_BANK
        jsr delay
        jmp deal
+       jsr pmsg
        +hdr MROW+2, C_GRN
        +t_bplanta

        ; ---- opcions del jugador (lletra clau en invers)
options jsr pmsg
        +hdr MROW+1, C_PUR
        !byte 0
        lsr candbl              ; (0 o 1) -> 0
        lda eb                  ; doblar: sense haver demanat i amb fitxes
        bne +
        lda mu
        cmp be
        lda mu+1
        sbc be+1
        bcc +
        inc candbl
        jsr pmsg_c
        +t_doblar
+       jsr pmsg_c
        +t_carta
        lda best                ; plantar-se amb 16 o mes
        cmp #16
        bcc +
        jsr pmsg_c
        +t_plantar
+       jsr pmsg_c
        +t_interr
-       jsr getkey
        cmp #'C'
        beq hit
        cmp #'D'
        bne +
        ldx candbl
        bne dbl
+       cmp #'P'               ; P (catala) o S (angles): plantar-se
        beq +
        cmp #'S'
        bne -
+       lda best
        cmp #16
        bcc -
        jsr pmsg
        +hdr MROW+2, C_GRN
        +t_plantes
dbl     clc                     ; tb += be, mu -= be
        lda tb
        adc be
        sta tb
        lda tb+1
        adc be+1
        sta tb+1
        sec
        lda mu
        sbc be
        sta mu
        lda mu+1
        sbc be+1
        sta mu+1
        !byte $2c               ; (BIT abs: salta l'INC)
hit     inc eb
        jmp deal

; ---------- aposta ----------
bet     jsr clr_top
        jsr showmu
        jsr pmsg
        +hdr MROW+2, C_PUR
        +t_quantes  ; (deixa el cursor a la columna 19, Y=0)
        sty be
        sty be+1
bet_lp  lda #C_FELT             ; cursor (bloc ple)
        jsr putc_nc
        jsr getkey
        cmp #13
        bne bet_k
        lda be                  ; RETURN: 0 < aposta <= fitxes
        ora be+1
        beq bet
        lda mu
        cmp be
        lda mu+1
        sbc be+1
        bcs dbl                 ; (el cursor l'esborra clr_top a deal)
        bcc bet
bet_k   cmp #20                 ; DEL
        bne bet_d
        lda be
        ora be+1
        beq bet_lp
        lda #C_BLANK
        jsr putc_nc
        dec cx
        ldx #be
        jsr div10
        beq bet_lp              ; (Z=1)
bet_d   cmp #$21                ; xifres, o les mateixes amb SHIFT
        bcc bet_lp
        cmp #$3a
        bcs bet_lp
        and #$0f
        cmp #10
        bcs bet_lp
        sta tmp
        ora be                  ; sense zeros a l'esquerra
        ora be+1
        beq bet_lp
        lda be+1                ; < 6400: cap desbordament
        cmp #$19
        bcs bet_lp
        ldx #10                 ; be = xifra + 10*be
        lda tmp
        ldy #0
-       clc
        adc be
        pha
        tya
        adc be+1
        tay
        pla
        dex
        bne -
        sta be
        sty be+1
        lda tmp
        ora #$b0                ; xifra de la ROM
        jsr putc
        bne bet_lp              ; (Z=0)

; =============================================================
;  RUTINES
; =============================================================
; ---- tapet: barana a les files 3 i 34, tapet verd entre mig
Q4      = WIDTH*HEIGHT/4        ; 980 = 4 x 245
!if Q4*4 != WIDTH*HEIGHT { !error "la pantalla ha de ser multiple de 4" }
table   ldx #Q4
-       lda #C_FELT
        sta SCREEN-1,x
        sta SCREEN-1+Q4,x
        sta SCREEN-1+2*Q4,x
        sta SCREEN-1+3*Q4,x
        lda #GREEN
        sta COLRAM-1,x
        sta COLRAM-1+Q4,x
        sta COLRAM-1+2*Q4,x
        sta COLRAM-1+3*Q4,x
        dex
        bne -
        ldx #WIDTH-1
-       lda #C_RAIL
        sta SCREEN+RAILROW*WIDTH,x
        lda #C_RAILB            ; sense perfil de baix: el fa la vora
        sta SCREEN+BOTROW*WIDTH,x
        lda #MC+RED
        sta COLRAM+RAILROW*WIDTH,x
        sta COLRAM+BOTROW*WIDTH,x
        dex
        bpl -
clr_top ldx #WIDTH*3-1          ; files de missatges (torna X=$ff)
        lda #C_BLANK
-       sta SCREEN+MROW*WIDTH,x
        dex
        bpl -
        rts

; ---- esborra la columna A de la pila (torna el tapet)
clrcol  tay
        ldx #STOP
        jsr setcur
        lda #GREEN
        sta curcol
        ldx #CARDH
-       lda #C_FELT
        jsr putc_nc
        jsr nextrow
        dex
        bne -
        rts

; ---- capsa: X fila, Y plantilla, A color; amplada 2+bw a tcol
plaque  ldy #tb_plq-tmpl
        lda #GREEN
        bne drawbox
draw_back
        ldx #STOP
        ldy #tb_back-tmpl
        lda #RED
drawbox sta curcol
drawbox_c
        sty tbase
        ldy tcol
        jsr setcur
        ldx tbase
--      lda tmpl,x              ; files d'aquest tipus (0 = fi)
        beq ++
        sta tmp
-       lda tmpl+1,x
        jsr putc
        lda bw
        sta cnt
---     lda tmpl+2,x
        jsr putc
        dec cnt
        bne ---
        lda tmpl+3,x
        jsr putc
        ldy tcol
        jsr crlf
        dec tmp
        bne -
        inx
        inx
        inx
        inx
        bne --                  ; (sempre)
++      rts

; ---- bloc de 3 columnes: X fila, cnt files, tmp index a cardtab,
;      tmp2 index a facecol ($ff = color de la carta)
blk3    ldy tcol
        iny
        jsr setcur
--      ldx tmp2
        bmi +
        lda facecol,x
        cmp #$10                ; roba: color segons el pal
        bcc ++
        lda robe
++      sta curcol
        inc tmp2
+       ldx #3
-       ldy tmp
        inc tmp
        lda cardtab,y
        jsr putc
        dex
        bne -
        jsr rowend
        bne --
        rts

rowend  ldy tcol                ; fila seguent de la zona central
        iny
        jsr crlf
        dec cnt
        rts

prank   ldx rank                ; valor de la carta (ROM, o el 10 propi)
        lda rankch-1,x
putc    jsr putc_nc
        inc cx
        rts
putc_nc ldy cx
        sta (sp),y
        lda curcol
        sta (cp),y
        rts

; ---- pantalla
setcur  lda #<(SCREEN-WIDTH)    ; X fila, Y columna
        sta sp
        sta cp
        lda #>(SCREEN-WIDTH)
        sta sp+1
        lda #>(COLRAM-WIDTH)
        sta cp+1
        sty cx
        inx
-       jsr nextrow
        dex
        bne -
        rts

crlf    sty cx                  ; columna Y de la fila seguent
nextrow lda sp
        clc
        adc #WIDTH
        sta sp
        sta cp
        bcc +
        inc sp+1
        inc cp+1
+       rts

; ---- missatges inline. pmsg: capcalera + text; pmsg_c: text al cursor.
;      Text: catala, $fe, angles i 0 (o $ff: aleshores salta a result). Un text sense
;      $fe es mostra tal qual amb lang = 0 (presentacio i credits).
;      Una lletra amb el bit 7 es una lletra clau i surt en invers vermell.
pmsg    sec
        !byte $24               ; (BIT zp: salta el CLC)
pmsg_c  clc
        pla
        sta mptr
        pla
        sta mptr+1
        ldx lang                ; textos per saltar: 0 catala, 1 angles
        stx sk
        bcc pm_lp
        jsr nextb               ; capcalera (torna Y=0)
        lsr                     ; C = hi ha columna
        pha
        bcc +
        jsr nextb
        tay
+       pla
        pha
        and #3
        tax
        lda coltab,x
        sta curcol
        pla
        lsr
        lsr
        tax
        jsr setcur
pm_lp   jsr nextb
        beq +++
        cmp #SEP
        beq pm_sep
        bcs result              ; $ff
        ldx sk                  ; (text de l'altra llengua: no s'escriu)
        bne pm_lp
        tax
        bpl ++                  ; lletra normal
        ldx #RED                ; lletra clau: invers vermell. El caracter propi
        stx curcol              ; K_x (cards.inc) es la lletra en negatiu
        and #$7f
        jsr tputc
        lda #PURPLE             ; (les lletres clau nomes surten en missatges lila)
        sta curcol
        bne pm_lp
++      jsr pchar               ; lletra o parella
        beq pm_lp               ; (Z=1)
pm_sep  dec sk                  ; $fe: catala 0 -> $ff (salta l'angles), angles 1 -> 0
        bcs pm_lp               ; (C=1)
+++     jsr nextb               ; tornar despres del 0 (amb Z=0)
        jmp (mptr)
; ---- un simbol del text: 1-63 lletra de la ROM; 64-127 parella de simbols (recursiu)
pchar   cmp #64
        bcc +
        tax
        lda+2 par2-64,x          ; (absolut: la taula es al fons de la pila)
        pha
        lda+2 par1-64,x
        jsr pchar
        pla
        bne pchar               ; (sempre: els simbols no son 0)
+       ora #$80                ; lletres de la ROM
        jmp tputc               ; (torna amb Z=1)

; ---------- final del torn ----------
result  ldx #D_MSG
        jsr delay
        ldx pl
        bne final
        lda best
        sta yy
        beq settle              ; el jugador s'ha passat
        inc pl
        jmp turn
final   lda best                ; banca >= jugador: guanya la banca
        cmp yy
        bcs settle
        lda yy                  ; gg = 1, o 2 amb natural / cinc cartes
        cmp #22
        lda #0
        adc #1
        sta gg

; ---------- cobrar ----------
settle  jsr clr_top
        jsr pmsg
        +hdr MROW, C_RED
        +t_resolta
        lda gg
        bne won
        jsr pmsg_c
        +t_guanyab
        bne shm                 ; (Z=0)
won     lda tb                  ; tornar l'aposta
        ldx tb+1
        jsr addmu
        lda tb                  ; premi = tb o 2*tb
        ldx tb+1
        lsr gg
        bcs +
        asl
        pha
        txa
        rol
        tax
        pla
+       sta num
        stx num+1
        jsr addmu
        jsr pmsg_c
        +t_guanyes
        jsr pnumv
shm     jsr showmu
        jsr pmsg
        +hdr MROW+2, C_PUR
        +t_prem
        jsr getkey
        lda mu
        ora mu+1
        bne +
        jmp ruin                ; (al buffer del cassette)
+       jmp newhand

addmu   clc                     ; mu += A/X, amb topall a 65535
        adc mu
        sta mu
        txa
        adc mu+1
        sta mu+1
        bcc +
        lda #$ff
        sta mu
        sta mu+1
+       rts

nextb   inc mptr
        bne +
        inc mptr+1
+       ldy #0
        lda (mptr),y
        rts

tputc   jsr putc                ; lletra a lletra, amb "tic"
        lda #$e0
        sta VOICE_H
        ldx #D_TYPE
        jsr delay
        stx VOICE_H             ; (X=0)
        rts

; ---- numeros
showmu  jsr pmsg
        +hdr MROW+1, C_RED
        +t_fitxes
        lda mu
        ldx mu+1
        !byte $2c               ; (BIT abs: salta el LDX #0)
pbyte   ldx #0
pnum    sta num                 ; A baix, X alt
        stx num+1
pnumv   lda #0
        pha
        ldx #num
-       jsr div10
        ora #$b0                ; xifra de la ROM
        pha
        lda num
        ora num+1
        bne -
-       pla
        beq ++
        jsr tputc
        beq -                   ; (Z=1)
div10   ldy #16                 ; (X) /= 10, A = residu. X = adreca zp
        lda #0
-       asl 0,x
        rol 1,x
        rol
        cmp #10
        bcc +
        sbc #10
        inc 0,x
+       dey
        bne -
++      rts

; ---- teclat, temps, atzar
getkey  lda #0
        sta NKEYS
-       jsr rnd
        jsr GETIN
        beq -
        and #$7f                ; ignorar SHIFT
        rts

delay                           ; X unitats de 2 jiffies (torna X=0, Z=1)
--      lda JIFFY
        clc
        adc #2
-       cmp JIFFY
        bne -
        dex
        bne --
        rts

rnd     lda rng+1               ; xorshift 16 bits
        lsr
        lda rng
        ror
        eor rng+1
        sta rng+1
        ror
        eor rng
        sta rng
        eor rng+1
        sta rng+1
        rts

; =============================================================
;  DADES
; =============================================================
rowmask !byte %010,%000,%101    ; pips per tipus de fila: centre, res, parella
sofs    !byte 0,9,18,27         ; pal gran de l'as (i color de cada figura: 0,9,18)
fofs    !byte 36,63,90          ; inici de cada figura a cardtab
; capses: [files, esquerra, mig x bw, dreta], 0 = fi
tmpl    !byte 1,C_TL,C_T,C_TR, 11,C_L,C_BLANK,C_BLANK, 1,C_BL,C_B,C_BR, 0
tmplf   !byte 1,C_TLF,C_T,C_TR, 11,C_BLANK,C_BLANK,C_BLANK, 1,C_BLF,C_B,C_BR, 0
tb_back !byte 1,C_BTL,C_BT,C_BTR, 11,C_BL_,C_BI,C_BR_, 1,C_BBL,C_BB,C_BBR, 0
tb_plq  !byte 1,C_TLF,C_T,C_TR, 2,C_BLANK,C_BLANK,C_BLANK, 1,C_BLF,C_B,C_BR, 0
!source "cards.inc"
!if BLACK != C_BLANK { !error "el retol suposa BLACK = C_BLANK" }
end_of_code
!if end_of_code > CHARSET { !error "El codi no hi cap! Sobren ", end_of_code-CHARSET }
        !fill CHARSET-*, 0      ; (lliure)
        !bin "charset.bin", 63*8        ; caracters 0-62 (el 63 no es fa servir)
r_end
}
!if NMIR*8 > 255 { !error "massa miralls per a l'index Y" }

; =============================================================
;  Blocs que l'arrencada descomprimeix a la memoria baixa (van dins del flux): build.py
;  els assembla aqui (LDUMMY), fora del PRG
; =============================================================
LDUMMY  = $5000
        * = LDUMMY
; ---- bloc que va al buffer del cassette ($033c-$03fb)
extra_src
!pseudopc EXTRA {
; ---------- t'has arruinat: una altra partida o sortir ----------
ruin    jsr table
        jsr pmsg
        +hdr MROW+1, C_RED|HCOL
        !byte (WIDTH-15)/2
        +t_ruina
        lda #100                ; si en vol una altra: 100 fitxes i remenar
        sta mu
        sta z
        jsr pmsg
        +hdr MROW+2, C_PUR|HCOL
        !byte (WIDTH-22)/2
        +t_altra
-       jsr getkey
        cmp #'N'
        beq +
        cmp #'S'                ; S (catala) o Y (angles): una altra
        beq ++
        cmp #'Y'
        bne -
++      jmp newhand
+
; ---------- sortir: credits i reiniciar el VIC ----------
        lda #$08                ; fons i vora negres
        sta $900f
        ldx #Q4                 ; pantalla buida
        lda #C_BLANK
-       sta SCREEN-1,x
        sta SCREEN-1+Q4,x
        sta SCREEN-1+2*Q4,x
        sta SCREEN-1+3*Q4,x
        dex
        bne -
        stx lang                ; (els credits nomes tenen un text)
        lda #WHITE
        sta curcol
        ldx #HEIGHT/2-1
        jsr jimsoft
        ldx #HEIGHT/2+1
        ldy #(WIDTH-14)/2
        jsr setcur
        jsr pmsg_c
        +t_thanks
cred_wait
        jmp stars               ; estrelles i reiniciar (a $02a1)
jimsoft ldy #(WIDTH-15)/2       ; "(c)jimsoft 2026" centrat a la fila X, color curcol
        jsr setcur              ; (tambe el fa servir la presentacio)
        jsr pmsg_c
        +t_jimsoft
        rts
; registres $9000-$900f (PAL). $9006-$9009 son de lectura i a $900a-$900d
; nomes cal el bit 7 a 0: hi posem coltab i robetab
vicini  !byte $06,$0f,WIDTH,HEIGHT*2,0,$cf   ; 35 files des de la linia 30: 280 de les 284 visibles
coltab  !byte RED,PURPLE,BLACK,BLUE     ; (els missatges "verds" van en negre: es llegeixen millor)
robetab !byte MC+BLUE,MC+RED,MC+BLACK,MC+PURPLE   ; roba per pal: piques cors trebols diamants
        !byte $95,$18           ; auxiliar taronja clar + volum 5; fons blanc, vora negra
extra_end
}
extra_len = extra_end-EXTRA
!if extra_len > $03fc-EXTRA { !error "el bloc no cap al buffer del cassette" }

; ---- bloc que va al fons de la pila ($0100-): la pila no hi arriba mai (fa servir
;      menys de 64 bytes des de $01ff)
low_src
!pseudopc LOW {
+t_parelles             ; parelles dels textos (textos.inc)
instr2  jsr pmsg                ; resta de les instruccions de la presentacio
        +hdr ITITLE+7, C_GRN|HCOL
        !byte (WIDTH-23)/2
        +t_regla3
        jsr pmsg
        +hdr ITITLE+8, C_GRN|HCOL
        !byte (WIDTH-23)/2
        +t_regla4
        rts
low_end
}
low_len = low_end-LOW
!if LOW+low_len > $01c0 { !error "el bloc no cap al fons de la pila" }

; ---- bloc que va a $02a1-$02ff (lliure al VIC-20): estrelles dels credits
extra3_src
!pseudopc EXTRA3 {
stars   lda #D_CRED             ; 5 s d'estrelles de colors que s'encenen i s'apaguen
        sta cnt                 ; per la pantalla (sense tocar el text), i reiniciar
st_lp   jsr rnd                 ; posicio a l'atzar (A = part alta)
        and #3
        tay
        lda rng
        cpy #3
        bne +
        cmp #<(WIDTH*HEIGHT)
        bcs st_lp
+       sta sp
        sta cp
        tya
        ora #>SCREEN
        sta sp+1
        eor #(>SCREEN) XOR (>COLRAM)
        sta cp+1
        ldy #0
        lda (sp),y
        bpl st_ok               ; buit
        cmp #$aa                ; "*" o "." (les lletres no es toquen)
        beq st_ok
        cmp #$ae
        bne st_nx
st_ok   lda rng+1
        bmi st_big
        and #$40
        beq st_put              ; s'apaga
        lda #$ae                ; "."
        bne st_put
st_big  lda #$aa                ; "*"
st_put  sta (sp),y
        lda rng                 ; color a l'atzar (no negre)
        lsr
        lsr
        lsr
        and #7
        bne +
        lda #7
+       sta (cp),y
st_nx   ldx #1
        jsr delay
        dec cnt
        bne st_lp
        jmp ($fffc)             ; reiniciar el VIC
extra3_end
}
extra3_len = extra3_end-EXTRA3
!if EXTRA3+extra3_len > $0300 { !error "el bloc no cap a $02a1-$02ff" }

; ---- bloc que va a la resta del buffer del BASIC ($0234-$0258)
extra2_src
!pseudopc EXTRA2 {
rustle  jsr noise               ; fregament de la carta: to i volum a l'atzar a cada pas
        ora #$e0
        sta VOICE_N
        jsr noise
        and #7
        ora #$90                ; (sense tocar l'auxiliar taronja clar)
        sta VOLUME
        ldx spd
        jmp delay
noise   lda nz                  ; LFSR de 8 bits (periode 255)
        asl
        bcc +
        eor #$1d
+       sta nz
        rts
extra2_end
}
extra2_len = extra2_end-EXTRA2
!if EXTRA2+extra2_len > $0259 { !error "el bloc no cap al buffer del BASIC" }



