#!/usr/bin/env python3
"""VINTIUNA PRO - textos comprimits.
Escriu textos.inc: una macro per text (+t_nom) i les taules de parelles (+t_parelles).
Compressio per parelles: els codis 64-127 representen una parella de simbols (que poden
ser lletres o altres parelles); pchar les desplega. {X} = lletra clau en invers.
Necessita cards.inc (genera_caracters.py: on son les lletres clau). Despres: python3 build.py"""
FI, SALT, SEP = 0, 0xff, 0xfe   # 0 = fi del text; $ff = fi i salta a result; $fe = separa les llengues
# (nom, catala, angles, final). Sense angles (None): el text nomes es mostra amb lang = 0
# (presentacio abans de triar, credits). Els espais del davant de l'angles el centren a
# la mateixa columna que el catala.
TEXTOS = [
    ('ruina',    "t'has arruinat!",            " you're broke!",            FI),
    ('altra',    "una altra partida? {S}/{N}", "   play again? {Y}/{N}",    FI),
    ('thanks',   "thanks claude!",             None,                        FI),
    ('jimsoft',  "(c)jimsoft 2026",            None,                        FI),
    ('barrejant',"barrejant...",               "shuffling...",              FI),
    ('banca',    "banca",                      "bank",                      FI),
    ('tu',       "tu",                         "you",                       FI),
    ('natural',  "vint-i-u natural!",          "natural 21!",               SALT),
    ('passat',   "t'has passat!",              "you're bust!",              SALT),
    ('bpassat',  "la banca s'ha passat!",      "bank is bust!",             SALT),
    ('cinc',     "5 cartes!",                  "5 cards!",                  SALT),
    ('tens21',   "tens 21!",                   "you have 21!",              SALT),
    ('bfa21',    "la banca fa 21!",            "bank has 21!",              SALT),
    ('bplanta',  "la banca es planta",         "bank stands",               SALT),
    ('doblar',   "{D}oblar ",                  "{D}ouble ",                 FI),
    ('carta',    "{C}arta ",                   "{C}ard ",                   FI),
    ('plantar',  "{P}lantar-se",               "{S}tand",                   FI),
    ('interr',   " ?",                         " ?",                        FI),
    ('plantes',  "et plantes.",                "you stand.",                SALT),
    ('quantes',  "quantes n'apostes? ",        "your bet? ",                FI),
    ('resolta',  "ma resolta. ",               "round over. ",              FI),
    ('guanyab',  "guanya la banca",            "bank wins",                 FI),
    ('guanyes',  "guanyes ",                   "you win ",                  FI),
    ('prem',     "prem tecla per continuar.",  "press any key to continue.",FI),
    ('fitxes',   "fitxes: ",                   "chips: ",                   FI),
    ('regla1',   "banca es planta a 17",       " bank stands on 17",        FI),
    ('regla2',   "natural i 5 cartes: x2",     "natural or 5 cards: x2",    FI),
    ('regla3',   "as: 1 o 11  figures: 10",    "ace: 1 or 11  faces: 10",   FI),
    ('regla4',   "plantar-se amb 16 o mes",    "  stand on 16 or more",     FI),
    ('titol',    "vintiuna pro",               None,                        FI),
    ('premuna',  "prem una tecla",             "press any key",             FI),
    ('menu',     "{E}nglish  {C}atala",        None,                        FI),
    ('titolen',  "pontoon pro",                None,                        FI),
]
def scr(ch):                               # codi de pantalla (com !scr d'ACME)
    if 'a'<=ch<='z': return ord(ch)-96
    assert 32<=ord(ch)<64, ch
    return ord(ch)
KEY={l.split()[0][2:]:int(l.split()[2]) for l in open('cards.inc') if l.startswith('K_')}   # genera_caracters.py
def simbols(t):
    out=[]; i=0
    while i<len(t):
        if t[i]=='{': out.append(('K',0x80|KEY[t[i+1].upper()])); i+=3   # lletra clau
        else: out.append(scr(t[i])); i+=1
    return out
seqs=[simbols(c)+([('S',SEP)]+simbols(e) if e is not None else []) for _,c,e,_ in TEXTOS]
parells=[]
for code in range(64,128):
    n={}
    for q in seqs:
        for a,b in zip(q,q[1:]):
            if isinstance(a,int) and isinstance(b,int): n[(a,b)]=n.get((a,b),0)+1
    if not n: break
    (a,b),c=max(n.items(),key=lambda kv:(kv[1],-kv[0][0],-kv[0][1]))
    if c<3: break                           # cada parella costa 2 bytes de taula
    parells.append((a,b))
    for k,q in enumerate(seqs):
        o=[]; i=0
        while i<len(q):
            if i+1<len(q) and q[i]==a and q[i+1]==b: o.append(code); i+=2
            else: o.append(q[i]); i+=1
        seqs[k]=o
def expand(c):
    if isinstance(c,tuple): return [c[1]]
    return [c] if c<64 else expand(parells[c-64][0])+expand(parells[c-64][1])
L=['; ---- generat per genera_textos.py: no editar a ma ----']
abans=despres=0
for (nom,c,e,fi),q in zip(TEXTOS,seqs):
    t=c if e is None else c+'|'+e
    ref=simbols(c)+([('S',SEP)]+simbols(e) if e is not None else [])
    assert [x for c in q for x in expand(c)]==[s if isinstance(s,int) else s[1] for s in ref]
    b=[c[1] if isinstance(c,tuple) else c for c in q]+[fi]
    abans+=len(ref)+1; despres+=len(b)
    L.append('!macro t_%-10s { !byte %s }   ; "%s"%s' % (nom, ','.join('$%02x'%x for x in b), t, ' + salt' if fi==SALT else ''))
L.append('!macro t_parelles {')
L.append('par1    !byte '+','.join('$%02x'%a for a,_ in parells))
L.append('par2    !byte '+','.join('$%02x'%b for _,b in parells))
L.append('}')
open('textos.inc','w').write('\n'.join(L)+'\n')
print('textos: %d bytes -> %d + %d de taula de parelles (%d parelles): estalvi %d'%(abans,despres,2*len(parells),len(parells),abans-despres-2*len(parells)))
