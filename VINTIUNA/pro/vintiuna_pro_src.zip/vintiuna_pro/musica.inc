; =============================================================
;  VINTIUNA PRO - musica de la presentacio: Guillem Tell (Rossini, 1829),
;  obertura, el Galop (primera seccio i segona), en Sol major.
;  Necessita: delay, gend (on es va quan es prem una tecla), NKEYS, VOICE_L/M/H/N,
;  VOLUME i les variables de pagina zero tmp, tmp2, sidx, gch, mrem, gt, gu.
;  Entrada: gloop. Es repeteix fins que es prem una tecla.
; =============================================================
; ---- cada volta del bucle es un cicle de 2 jiffies; una unitat (corxera de la
;      transcripcio) son 3 cicles. Byte de la tonada = nota (bits 0-3) | durada en
;      unitats (4-6); nota 15 = control: el nibble alt es l'acord.
gloop   lda #0
        sta sidx
        sta mrem
        sta gch                 ; (comenca en Sol)
        sta gt
        lda #6                  ; l'anacrusi son les unitats 6 i 7 d'un compas
        sta gu
gtick   lda #0                  ; el cop de soroll dura un sol cicle
        sta VOICE_N
        lda mrem                ; ---- melodia
        bne gm_dec
gm_get  ldy sidx
        lda tune,y
        iny
        cpy #TUNELEN
        bne +
        ldy #0
+       sty sidx
        sta tmp
        and #$0f
        cmp #$0f
        bne gm_play
        lda tmp                 ; control: gch = acord x 4
        lsr
        lsr
        and #$3c
        sta gch
        bpl gm_get              ; (sempre)
gm_play tay
        lda gpt,y
        sta VOICE_H
        lda tmp                 ; cicles = durada x 3
        lsr
        lsr
        lsr
        lsr
        sta mrem
        asl
        adc mrem
        sta mrem
gm_dec  dec mrem                ; l'ultim cicle de cada nota, en silenci
        bne +
        lda #0
        sta VOICE_H
+       lda gt                  ; ---- acompanyament, al primer cicle de cada unitat
        bne gacc_e
        ldx #$95                ; volum 5; als temps forts (unitats 0 i 4), 7
        lda gu
        and #3
        bne +
        ldx #$97
+       stx VOLUME              ; (sense tocar l'auxiliar taronja clar)
        lda gu
        lsr
        bcs gsil                ; unitat senar: silenci (tot curt, com un galop)
        sta tmp2                ; unitat/2: 0 baix, 1 acord A, 2 baix quinta, 3 acord B
        ora gch
        tay
        lda gvoc,y
        tay
        lda gpt,y
        lsr tmp2
        bcs gpah
        sta VOICE_L             ; oom
        bcc gacc_e              ; (sempre)
gpah    sta VOICE_M             ; pah
        lda #$f0                ; i un cop de soroll
        sta VOICE_N
        bne gacc_e              ; (sempre)
gsil    lda #0
        sta VOICE_L
        sta VOICE_M
gacc_e  ldx #1                  ; ---- un cicle
        jsr delay
        inc gt
        lda gt
        cmp #3
        bne +
        stx gt                  ; (X=0)
        inc gu
        lda gu
        and #7
        sta gu
+       lda NKEYS
        bne +
        jmp gtick
+       jmp gend
; RE MI FA# SOL LA SI DO DO# RE' MI': 1108405/32/(256-v) Hz a la veu aguda (PAL);
; a la mitjana, una octava avall; a la greu, dues
gpt     !byte 138,151,162,168,177,186,190,194,197,203
tune
        !byte $10,$10,$0f,$20,$10,$10,$20,$20,$23,$24,$25,$10,$10,$20,$10,$10
        !byte $23,$25,$1f,$24,$22,$20,$10,$10,$0f,$20,$10,$10,$20,$20,$23,$24
        !byte $25,$13,$15,$1f,$58,$16,$15,$14,$0f,$23,$25,$23
        !byte $15,$15,$2f,$25,$15,$15,$25,$25,$25,$29,$25,$29,$25,$29,$25,$24
        !byte $23,$22,$21,$15,$15,$25,$15,$15,$25,$25,$25,$29,$25,$29,$25,$29
        !byte $3f,$28,$27,$4f,$68,$24,$1f,$24,$14,$14,$24,$25,$26,$44,$26,$0f
        !byte $25,$43,$25,$1f,$24,$40,$24,$24,$14,$14,$24,$25,$26,$44,$26,$0f
        !byte $25,$43,$25,$4f,$24,$20,$20
tune_end
TUNELEN = tune_end-tune
; veus per acord: [baix fonamental, acord A, baix quinta, acord B] (index a gpt).
; El baix sona a la veu greu (2 octaves avall), l'acord a la mitjana (1 octava avall)
gvoc    !byte 3,5,0,8           ; 0 Sol:  Sol  Si   Re  Re
        !byte 0,2,4,6           ; 1 Re7:  Re   Fa#  La  Do
        !byte 1,3,5,5           ; 2 Mim:  Mi   Sol  Si  Si
        !byte 4,7,1,3           ; 3 La7:  La   Do#  Mi  Sol
        !byte 0,2,4,4           ; 4 Re:   Re   Fa#  La  La
