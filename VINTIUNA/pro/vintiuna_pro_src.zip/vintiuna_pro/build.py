#!/usr/bin/env python3
"""VINTIUNA PRO - construccio del PRG.
1. Assembla amb el bloc R (final de l'arrencada, musica, programa i caracters 0-62) a
   RDUMMY, els blocs de memoria baixa a LDUMMY i un flux buit.
2. Fa el flux de segments amb blz2.py: caracters 64-97, blocs de memoria baixa i el bloc R
   (l'ultim, que es descomprimeix al mateix lloc: el flux acaba a $1dff, darrere del final
   del bloc, $1df7) -> r.blz2, r.inc
3. Torna a assemblar, comprova que res no ha canviat, descomprimeix el PRG en una memoria
   simulada com ho fara el 6502 i retalla el PRG a $1dff."""
import subprocess, sys
import blz2

ACME = 'acme'           # (posa-hi el cami de l'ACME si no es al PATH)
RSTART, RDUMMY, REND, PRGEND = 0x1200, 0x4000, 0x1df8, 0x1e00

def acme():
    r = subprocess.run([ACME, '-f', 'cbm', '-o', 'tmp_build.prg', '-l', 'labels.txt',
                        'vintiuna_pro.asm'], capture_output=True, text=True)
    sys.stdout.write(r.stdout + r.stderr)
    if r.returncode:
        raise SystemExit('error d\'assemblatge')
    d = open('tmp_build.prg', 'rb').read()
    labels = {}
    for l in open('labels.txt'):
        p = l.split()
        if len(p) >= 3 and p[1] == '=':
            labels[p[0]] = p[2]
    return d, labels

def rblock(d):
    base = d[0] | d[1] << 8
    o = RDUMMY - base + 2
    return d[o:o + REND - RSTART]

def write(comp):
    open('r.inc', 'w').write('; ---- generat per build.py: no editar a ma ----\n'
                             'SLEN    = %d          ; flux comprimit\n' % len(comp))
    open('r.blz2', 'wb').write(comp)

def segments(d, L):
    base = d[0] | d[1] << 8
    def at(a, n):
        return d[2 + a - base:2 + a - base + n]
    cs = open('charset.bin', 'rb').read()
    return [(0x1e00, cs[512:L['MIRDST'] * 8]),
            (L['LOW'], at(L['low_src'], L['low_len'])),
            (L['EXTRA'], at(L['extra_src'], L['extra_len'])),
            (L['EXTRA2'], at(L['extra2_src'], L['extra2_len'])),
            (L['EXTRA3'], at(L['extra3_src'], L['extra3_len'])),
            (RSTART, rblock(d))]

def nums(l):
    return {k: int(v.strip('$;'), 16) for k, v in l.items() if v.startswith('$')}

write(b'')
d1, l1 = acme()
segs = segments(d1, nums(l1))
assert len(segs[-1][1]) == REND - RSTART
comp = blz2.encode_segments(segs)
write(comp)
d2, l2 = acme()
assert segments(d2, nums(l2)) == segs, 'els blocs han canviat entre les dues passades'
diff = [k for k in l1 if l1[k] != l2.get(k) and k not in ('stream', 'SLEN')]
assert not diff, 'etiquetes canviades: %s' % diff
base = d2[0] | d2[1] << 8
prg = d2[:2 + PRGEND - base]
L = nums(l2)
# arrencada simulada: el PRG a memoria, el flux descomprimit al mateix lloc
mem = bytearray(65536)
mem[base:PRGEND] = prg[2:]
assert bytes(mem[L['stream']:PRGEND]) == comp
end = blz2.decode_mem(mem, L['stream'])
assert end == PRGEND, 'el flux no acaba on toca'
for a, x in segs:
    assert bytes(mem[a:a + len(x)]) == x, 'el segment de $%04x no surt be (trepitjat?)' % a
open('vintiuna_pro.prg', 'wb').write(prg)
print('flux: %s -> %d bytes' % (' + '.join('%d' % len(x) for a, x in segs), len(comp)))
print('lliures: zona de $1200 (abans de descomprimir) %d, dalt %d (viu a la presentacio %d), programa %d' % (
    L['stream'] - L['dead_end'], RSTART - L['top_end'], 0x113c - L['toplive_end'],
    L['CHARSET'] - L['end_of_code']))
