; ---- generat per genera_textos.py: no editar a ma ----
!macro t_ruina      { !byte $14,$27,$78,$43,$12,$15,$45,$74,$fe,$20,$4b,$27,$12,$54,$02,$12,$0f,$6d,$21,$00 }   ; "t'has arruinat!| you're broke!"
!macro t_altra      { !byte $72,$4e,$14,$12,$41,$10,$67,$09,$04,$01,$65,$93,$2f,$c1,$fe,$51,$20,$10,$6e,$60,$01,$07,$01,$45,$65,$99,$2f,$c1,$00 }   ; "una altra partida? {S}/{N}|   play again? {Y}/{N}"
!macro t_thanks     { !byte $14,$08,$40,$0b,$47,$03,$6e,$15,$04,$05,$21,$00 }   ; "thanks claude!"
!macro t_jimsoft    { !byte $28,$03,$29,$0a,$09,$0d,$13,$0f,$06,$14,$20,$32,$30,$32,$36,$00 }   ; "(c)jimsoft 2026"
!macro t_barrejant  { !byte $02,$43,$12,$05,$0a,$4d,$61,$2e,$fe,$13,$08,$15,$06,$06,$0c,$45,$07,$61,$2e,$00 }   ; "barrejant...|shuffling..."
!macro t_banca      { !byte $52,$01,$fe,$53,$00 }   ; "banca|bank"
!macro t_tu         { !byte $14,$15,$fe,$4b,$00 }   ; "tu|you"
!macro t_natural    { !byte $16,$45,$14,$2d,$09,$2d,$15,$20,$6b,$21,$fe,$6b,$20,$5a,$ff }   ; "vint-i-u natural!|natural 21!" + salt
!macro t_passat     { !byte $14,$27,$78,$10,$6c,$13,$74,$fe,$4b,$27,$12,$54,$02,$15,$4a,$21,$ff }   ; "t'has passat!|you're bust!" + salt
!macro t_bpassat    { !byte $76,$13,$27,$08,$41,$10,$6c,$13,$74,$fe,$5c,$09,$47,$02,$15,$4a,$21,$ff }   ; "la banca s'ha passat!|bank is bust!" + salt
!macro t_cinc       { !byte $62,$67,$42,$21,$fe,$62,$73,$13,$21,$ff }   ; "5 cartes!|5 cards!" + salt
!macro t_tens21     { !byte $71,$0e,$47,$5a,$fe,$75,$5d,$16,$54,$5a,$ff }   ; "tens 21!|you have 21!" + salt
!macro t_bfa21      { !byte $76,$06,$41,$5a,$fe,$5c,$78,$5a,$ff }   ; "la banca fa 21!|bank has 21!" + salt
!macro t_bplanta    { !byte $76,$66,$5f,$01,$fe,$5c,$68,$13,$ff }   ; "la banca es planta|bank stands" + salt
!macro t_doblar     { !byte $84,$0f,$02,$0c,$43,$20,$fe,$84,$46,$02,$0c,$54,$00 }   ; "{D}oblar |{D}ouble "
!macro t_carta      { !byte $c0,$67,$41,$fe,$c0,$73,$20,$00 }   ; "{C}arta |{C}ard "
!macro t_plantar    { !byte $90,$56,$43,$2d,$13,$05,$fe,$93,$14,$5b,$00 }   ; "{P}lantar-se|{S}tand"
!macro t_interr     { !byte $20,$3f,$fe,$20,$3f,$00 }   ; " ?| ?"
!macro t_plantes    { !byte $05,$14,$20,$5f,$42,$2e,$fe,$75,$68,$2e,$ff }   ; "et plantes.|you stand." + salt
!macro t_quantes    { !byte $11,$15,$4d,$66,$0e,$27,$01,$10,$0f,$4a,$42,$65,$fe,$4b,$70,$02,$05,$14,$65,$00 }   ; "quantes n'apostes? |your bet? "
!macro t_resolta    { !byte $0d,$41,$12,$42,$0f,$0c,$14,$01,$2e,$20,$fe,$12,$46,$0e,$04,$4c,$16,$05,$12,$2e,$20,$00 }   ; "ma resolta. |round over. "
!macro t_guanyab    { !byte $07,$15,$40,$19,$41,$55,$52,$01,$fe,$5c,$17,$45,$13,$00 }   ; "guanya la banca|bank wins"
!macro t_guanyes    { !byte $07,$15,$40,$19,$66,$fe,$75,$17,$45,$20,$00 }   ; "guanyes |you win "
!macro t_prem       { !byte $4f,$05,$0d,$20,$71,$03,$55,$10,$05,$12,$50,$77,$45,$15,$43,$2e,$fe,$4f,$42,$47,$40,$60,$6d,$60,$14,$0f,$50,$77,$45,$15,$05,$2e,$00 }   ; "prem tecla per continuar.|press any key to continue."
!macro t_fitxes     { !byte $06,$09,$14,$18,$42,$63,$fe,$03,$08,$09,$10,$13,$63,$00 }   ; "fitxes: |chips: "
!macro t_regla1     { !byte $69,$66,$5f,$41,$41,$31,$37,$fe,$20,$5c,$68,$47,$57,$48,$37,$00 }   ; "banca es planta a 17| bank stands on 17"
!macro t_regla2     { !byte $6b,$20,$09,$20,$62,$67,$42,$63,$18,$32,$fe,$6b,$4c,$70,$62,$73,$13,$63,$18,$32,$00 }   ; "natural i 5 cartes: x2|natural or 5 cards: x2"
!macro t_regla3     { !byte $6c,$64,$4c,$48,$31,$51,$06,$09,$07,$58,$42,$64,$30,$fe,$01,$03,$05,$64,$4c,$12,$48,$31,$51,$06,$01,$03,$42,$64,$30,$00 }   ; "as: 1 o 11  figures: 10|ace: 1 or 11  faces: 10"
!macro t_regla4     { !byte $5f,$43,$2d,$13,$54,$01,$0d,$02,$48,$36,$4c,$20,$0d,$42,$fe,$51,$68,$4c,$0e,$48,$36,$4c,$70,$0d,$0f,$12,$05,$00 }   ; "plantar-se amb 16 o mes|  stand on 16 or more"
!macro t_titol      { !byte $16,$45,$14,$09,$72,$4f,$0f,$00 }   ; "vintiuna pro"
!macro t_premuna    { !byte $4f,$05,$0d,$20,$72,$71,$03,$6e,$fe,$4f,$42,$47,$40,$60,$6d,$19,$00 }   ; "prem una tecla|press any key"
!macro t_menu       { !byte $85,$0e,$07,$0c,$09,$13,$08,$51,$c0,$49,$4e,$01,$00 }   ; "{E}nglish  {C}atala"
!macro t_titolen    { !byte $10,$77,$0f,$57,$20,$4f,$0f,$00 }   ; "pontoon pro"
!macro t_parelles {
par1    !byte $01,$01,$05,$01,$02,$09,$0f,$13,$20,$01,$13,$19,$20,$40,$01,$10,$20,$20,$44,$44,$05,$0c,$0c,$0f,$15,$31,$32,$40,$53,$08,$0e,$10,$19,$2e,$35,$3a,$3a,$3f,$42,$43,$4a,$52,$58,$5e,$01,$0b,$0c,$0e,$12,$14,$15,$43,$49,$4b,$55,$57,$5d
par2    !byte $0e,$20,$13,$12,$40,$0e,$15,$20,$31,$14,$14,$46,$0f,$14,$0c,$12,$03,$20,$03,$0b,$20,$41,$4d,$0e,$12,$21,$59,$04,$20,$01,$49,$56,$20,$2e,$50,$20,$48,$20,$20,$14,$5b,$41,$4e,$6a,$13,$05,$01,$41,$20,$05,$6f,$04,$21,$20,$69,$14,$47
}
