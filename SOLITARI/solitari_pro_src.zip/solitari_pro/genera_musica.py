# The Entertainer (Scott Joplin, 1902, domini public): primera part, a 3 veus
N={'C':135,'C#':143,'D':147,'D#':151,'E':159,'F':163,'F#':167,'G':175,'G#':179,'A':183,'A#':187,'B':191,
   "C'":195,"C#'":199,"D'":201,"D#'":203,"E'":207,"F'":209,"F#'":212,"G'":215}
bars = """D D#
E C' - E C' - E C'
- - - r r r C' D'
D#' E' C' D' E' - B D'
- C' - - - r D D#
E C' - E C' - E C'
- - - r r r A G
F# A C' E' - D' C' A
D' - - - - r D D#
E C' - E C' - E C'
- - - r r r C' D'
D#' E' C' D' E' - B D'
- C' - - r C' D' E'
C' D' E' - C' D' C' E'
C' D' E' - C' D' C' E'
C' D' E' - B - D' -
C' - - - - - r r""".split()
ev=[]
for t in bars:
    if t=='-': ev[-1][1]+=1
    else: ev.append([0x80 if t=='r' else N[t],0])
out=[]
for v,h in ev:
    out.append(v)
    if h: out.append(h)
out.append(0)
CH={'C':(135,175,159),'G7':(175,147,163),'D7':(147,183,167),'F':(163,195,183)}
prog='C C G7 C C C D7 G7 C C G7 C C F G7 C'.split()
harm=[0,0,0]+[x for c in prog for x in CH[c]]
def fmt(name,b):
    s=''
    for i in range(0,len(b),16): s+=('%-8s' % (name if i==0 else ''))+'!byte '+','.join(str(x) for x in b[i:i+16])+'\n'
    return s
open('musica.inc','w').write('; ---- generat per genera_musica.py: The Entertainer (S. Joplin, 1902)\n'+fmt('mel',out))
open('harmonia.inc','w').write('; ---- generat per genera_musica.py\n'+fmt('harm',harm))
print(len(out),len(harm),'passos',sum(1+h for v,h in ev))
