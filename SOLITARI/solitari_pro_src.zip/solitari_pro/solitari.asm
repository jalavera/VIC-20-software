; =============================================================
;  SOLITARI PRO  -  Klondike per al VIC-20 amb +3 KB, PAL
;  Cartes de 4x6 caselles (genera_cartes.py), pantalla 28x35, joystick
;  Assemblar:  acme -f cbm -o solitari.prg solitari.asm   (necessita cards.inc i charset.bin)
;  Memoria:    programa $0401-$0fff; al PRG, a $1000 (despres la pantalla) els caracters,
;              que l'arrencada copia a $1c00; taules i textos a $13d4; desfer i piles a
;              $1600-$1947
; =============================================================
!cpu 6502

SCREEN  = $1000
COLRAM  = $9400
CHARSET = $1c00
WIDTH   = 28
HEIGHT  = 35
NCHARS  = 115           ; caracters propis ($1c00-)
UNDO    = $1b00         ; desfer: 4 bytes per jugada (64 jugades)
NUNDO   = 64
PILES   = $033c         ; buffer del cassette: munt (52, pel repartiment), descart (24), bases (4x13)
PLEN    = PILES+128         ; nombre de cartes de cada pila (13)
TPILES  = $0200         ; columnes 6-9 (4x19) al buffer d'entrada del BASIC
TPILES2 = $02a1         ; columnes 10-12 (3x19), lliure al VIC-20
!if TPILES+4*19 > $0259 { !error "les columnes no hi caben" }
!if TPILES2+3*19 > $0300 { !error "les columnes no hi caben" }
!if PLEN+13 > $03fc { !error "PLEN fora del buffer" }

VOICE_L = $900a
VOICE_M = $900b
VOICE_H = $900c
VOICE_N = $900d
VOLUME  = $900e
JIFFY   = $a2

BLACK=0 : WHITE=1 : RED=2 : CYAN=3 : PURPLE=4 : GREEN=5 : BLUE=6 : YELLOW=7 : MC=8

; piles: 0 munt, 1 descart, 2-5 bases, 6-12 columnes
STOCK=0 : WASTE=1 : FOUND=2 : TAB=6
ROWMENU = 1             ; fila del menu (la 0, buida: alguns emuladors la tallen)
ROWSTAT = 2             ; punts, jugades i temps
ROWTOP  = 4             ; fila de les piles de dalt
ROWTAB  = 13            ; fila de les columnes
CARDT   = 8             ; cartes de dalt: 4x8
CARDH   = 10            ; cartes de les columnes: 4x10
MAXN    = HEIGHT-ROWTAB-CARDH+1   ; cartes d'una columna que hi caben sense apretar
MENU    = $ff           ; cur_p al menu

; ---------- pagina zero ----------
sp      = $10           ; (2) punter pantalla
cp      = $12           ; (2) punter color
ptr     = $14           ; (2)
tmp     = $16
tmp2    = $17
tmp3    = $18
pcol    = $19           ; color de la casella
row     = $1a
col     = $1b
cc      = $1c           ; carta (bit 7: de cara)
full    = $1d
edge    = $1e
ink     = $1f
cur_p   = $20           ; cursor: pila (MENU = menu)
cur_d   = $21           ; cursor: index de la carta a la pila
cur_m   = $22           ; cursor: opcio del menu
hsrc    = $23           ; pila agafada ($ff: res)
hstart  = $24           ; primera carta agafada
drawn   = $25           ; 1 o 3 cartes cada cop
sound   = $26           ; 0 = so
lang    = $27           ; 0 catala, 1 angles
score   = $28           ; (2)
moves   = $2a           ; (2)
secs    = $2c
mins    = $2d
jcnt    = $2e
lastj   = $2f
pjoy    = $30
rep     = $31
nund    = $32           ; jugades a desfer
sndt    = $33
sndp    = $34
rng     = $35           ; (2)
srank   = $37
ssuit   = $38
num     = $39           ; (2)
mv_s    = $3b           ; jugada: origen, desti, nombre, girada, punts
mv_d    = $3c
mv_n    = $3d
mv_f    = $3e
mv_sc   = $3f
won     = $40
lastsec = $41
anyk    = $46           ; 1: a una columna buida hi va qualsevol carta
iopt    = $47           ; presentacio: opcio triada
body    = $48               ; files del cos de la carta (6 o 8)
boff    = $49               ; fila del cos on comencen els dibuixos (0 o 1)
bt      = $4a
sub     = $4b               ; menu de NOVA: confirmar / sortir / tornar
ingame  = $4c               ; 1: hi ha una partida comencada (OPCIONS hi torna)
swon    = $4d               ; won guardat mentre s'es a les opcions
ianp    = $4e               ; presentacio: nota de la musica ja animada
iak     = $4f
mon     = $50               ; musica de la portada: 1 sona
mtim    = $51
mstep   = $52
mptr    = $53
mhold   = $54
hptr    = $55
hst     = $56               ; pista: primera carta que es mouria
rowhi   = $60               ; ($60-$82) adreces de les files, fetes a l'arrencada
rowlo   = $03c9             ; ($03c9-$03eb) buffer del cassette, darrere de PLEN
cool    = $45           ; cicles sense acceptar direccions noves
COOL    = 6

        * = $0401
        !word +, 10
        !byte $9e
        !text "1037"
        !byte 0
+       !word 0
; ---------- arrencada ($040d) ----------
        sei
        jsr boot2               ; (a $1c00: el VIC, la pila i les taules, abans dels caracters)
        ldx #0                  ; caracters a $1c00 (4 pagines)
-       lda CSRC,x
        sta CHARSET,x
        lda CSRC+$100,x
        sta CHARSET+$100,x
        lda CSRC+$200,x
        sta CHARSET+$200,x
        lda CSRC+$300,x
        sta CHARSET+$300,x
        inx
        bne -
        cli
        lda #$80
        sta $0291               ; sense canvi de minuscules
        ldx #$50                ; variables a 0 ($10-$5f): el BASIC hi deixa de tot
        lda #0
-       sta $0f,x
        dex
        bne -
        lda #3
        sta drawn
        lda $9124
        sta rng
        lda $9125
        ora #1
        sta rng+1
        jmp intro
newgame ldx #$ff                ; (pila neta: s'hi arriba des de qualsevol lloc)
        txs
        stx ingame
        jsr deal
        jsr drawall
        jmp main


; =============================================================
;  REPARTIR
; =============================================================
deal    ldx #51                 ; baralla ordenada a la pila del munt (de cara avall)
-       txa
        sta PILES,x             ; (la pila 0 comenca a PILES)
        dex
        bpl -
        ldx #51                 ; barrejar (Fisher-Yates)
dl_sh   stx tmp
-       jsr rnd
        and #$3f
        cmp tmp
        beq +
        bcs -
+       tay
        lda PILES,x
        pha
        lda PILES,y
        sta PILES,x
        pla
        sta PILES,y
        dex
        bne dl_sh
        lda #52
        sta PLEN
        ldx #12
        lda #0
-       sta PLEN,x              ; la resta, buides
        dex
        bne -
        ldx #0                  ; columnes: k cartes a la columna k, la darrera de cara
dl_col  stx tmp2
        lda #0
        sta tmp3
-       jsr popstock
        ldy tmp3
        cpy tmp2
        bne +
        ora #$80
+       pha
        txa
        clc
        adc #TAB
        tax
        pla
        jsr pushx
        ldx tmp2
        inc tmp3
        lda tmp3
        cmp tmp2
        bcc -
        beq -
        inx
        cpx #7
        bne dl_col
        lda #0
        sta score
        sta score+1
        sta moves
        sta moves+1
        sta secs
        sta mins
        sta nund
        sta won
        sta cur_d
        lda #$ff
        sta hsrc
        sta lastsec
        lda #TAB
        sta cur_p
        jsr curtop
        rts

popstock                        ; A = carta de dalt del munt (X conservat)
        stx tmp
        dec PLEN
        ldy PLEN
        lda PILES,y
        ldx tmp
        rts

; ---- piles: ptr = adreca de la pila X
pbase   lda pblo,x
        sta ptr
        lda pbhi,x
        sta ptr+1
        rts
pushx   pha                     ; posa A a dalt de la pila X
        jsr pbase
        ldy PLEN,x
        pla
        sta (ptr),y
        inc PLEN,x
        rts
popx    jsr pbase               ; A = treu la carta de dalt de la pila X
        dec PLEN,x
        ldy PLEN,x
        lda (ptr),y
        rts
topx    jsr pbase               ; A = carta de dalt de la pila X (Z=1 si es buida)
        ldy PLEN,x
        beq +
        dey
        lda (ptr),y
+       rts

; ---- atzar: xorshift de 16 bits
rnd     lda rng+1
        lsr
        lda rng
        ror
        eor rng+1
        sta rng+1
        ror
        eor rng
        sta rng
        eor rng+1
        sta rng+1
        rts

; =============================================================
;  BUCLE PRINCIPAL
; =============================================================
main    jsr wait                ; un cicle (temps i so)
        jsr input
        beq main
        ldx won
        beq +
        cmp #$41                ; partida guanyada: N, prou
        bne ++
        jmp quit
++      cmp #$43                ; S, Y o el boto: una altra
        beq +++
        and #$20
        beq main
+++     jmp newgame
+       tax
        and #$40
        beq +
        txa                     ; tecla especial: F1 menu, N nova, U desfer, S so
        and #3
        bne ++
        jsr f1menu
        jmp main
++      clc
        adc #$ff                ; 1-3 -> opcio del menu 0, 1, 2
        sta cur_m
        beq mk_n                ; (N dues vegades: nova partida confirmada)
        ldy #0
        sty sub
mk_n    jsr menuact
        jsr drawmenu
        jmp main
+       txa
        jsr action
        jmp main

; ---- espera el jiffy seguent: temps i so
wait    lda JIFFY
        cmp lastj
        beq wait
        sta lastj
        jmp tick

; ---- entrada d'aquest cicle: A = bits (2 amunt, 3 avall, 4 esquerra, 5 boto, 7 dreta;
;      $40+n tecla especial). Teclat: cursors, espai/RETURN; F1 N U S
input   jsr $ffe4
        beq in_joy
        ldx #kyn-1
-       cmp kycode,x
        beq +
        dex
        bpl -
        bmi in_joy
+       lda kyact,x
        rts
in_joy  jsr joyclean
        tax
        eor pjoy                ; tecles noves
        stx pjoy
        and pjoy
        ldx cool                ; just despres d'una accio, una direccio "nova" es rebot
        beq +
        dec cool
        and #$20                ; (del joystick tactil): nomes compta el boto
+       tax
        beq in_rep
        ldx #20                 ; primera repeticio als 20 cicles
        stx rep
        ldx #COOL
        stx cool
        rts
in_rep  lda pjoy                ; direccio mantinguda: es repeteix
        and #$9c
        beq ++
        dec rep
        bne +
        ldx #5
        stx rep
        rts
+       lda #0
++      rts

; ---- joystick: A = bits premuts (2 amunt, 3 avall, 4 esquerra, 5 boto, 7 dreta)
readjoy lda $9111
        and #$3c
        sta tmp
        sei
        lda #$7f
        sta $9122
        lda $9120
        ldx #$ff
        stx $9122
        cli
        and #$80
        ora tmp
        eor #$bc
        rts

; ---- temps i so (un cop per jiffy)
tick    lda won
        bne tk_snd
        inc jcnt
        lda jcnt
        cmp #60
        bcc tk_snd
        lda #0
        sta jcnt
        inc secs
        lda secs
        cmp #60
        bcc +
        lda #0
        sta secs
        inc mins
+       jsr status
tk_snd  lda sndt
        beq +++
        dec sndt
        bne +++
        ldx sndp                ; nota seguent de la melodia
        beq ++
        lda melody,x
        beq +
        sta VOICE_H
        inc sndp
        lda #8
        sta sndt
        rts
+       sta sndp
++      lda #0
        sta VOICE_L
        sta VOICE_M
        sta VOICE_H
        sta VOICE_N
+++     rts

; ---- efectes: X = efecte
SND_CLAC=0 : SND_FREG=1 : SND_ERR=2
sfx     lda sound
        bne +
        lda sfxreg,x
        tay
        lda sfxval,x
        sta $9000,y
        lda sfxdur,x
        sta sndt
+       rts
sfxreg  !byte $0d,$0d,$0a
sfxval  !byte $f4,$e2,$9c
sfxdur  !byte 2,4,14
fanfare lda sound
        bne +
        lda #1
        sta sndp
        lda #1
        sta sndt
+       rts

; =============================================================
;  ACCIONS (A = tecles: 2 amunt, 3 avall, 4 esquerra, 5 boto, 7 dreta)
; =============================================================
action  sta tmp3
        lda cur_p
        cmp #MENU
        bne ac_game
        lda tmp3                ; ---- al menu
        and #$20
        beq +
        jmp menuact
+       lda tmp3
        and #$08
        beq +
        lda #STOCK              ; avall: a les piles de dalt
        sta cur_p
        jsr curtop
        lda #0                  ; (fora del menu: s'oblida el de NOVA)
        sta sub
        jsr drawmenu
        jmp drawpile_c
+       lda tmp3
        and #$10
        beq +
        lda cur_m
        beq ++
        dec cur_m
        jmp drawmenu
+       lda tmp3
        bpl ++
        lda cur_m
        cmp #3
        bcs ++
        inc cur_m
        jmp drawmenu
++      rts

ac_game lda tmp3
        and #$20
        beq +
        jmp fire
+       lda cur_p               ; X = pila abans de moure
        sta tmp2
        lda tmp3
        and #$04
        beq ac_dn
        lda cur_p               ; ---- amunt
        cmp #TAB
        bcc ac_menu
        jsr firstup             ; primera carta de cara de la columna
        cmp cur_d
        bcs +
        dec cur_d               ; dins de la columna
        jmp redraw2
+       ldx cur_p               ; a les piles de dalt
        lda uptab-TAB,x
        sta cur_p
        jsr curtop
        jmp redraw2
ac_menu lda #MENU               ; al menu
        sta cur_p
        jsr drawpile_o
        jmp drawmenu
ac_dn   lda tmp3
        and #$08
        beq ac_lr
        lda cur_p               ; ---- avall
        cmp #TAB
        bcs +
        tax
        lda dntab,x
        sta cur_p
        jsr curtop
        jmp redraw2
+       ldx cur_p
        lda PLEN,x
        sec
        sbc #1
        bcc +
        cmp cur_d
        beq +
        bcc +
        inc cur_d
        jmp redraw2
+       rts
ac_lr   lda tmp3
        and #$10
        beq ac_r
        lda cur_p               ; ---- esquerra
        beq +
        cmp #TAB
        beq +
        dec cur_p
        jsr curtop
        jmp redraw2
+       rts
ac_r    lda tmp3
        bpl +
        lda cur_p               ; ---- dreta
        cmp #FOUND+3
        beq +
        cmp #TAB+6
        beq +
        inc cur_p
        jsr curtop
        jmp redraw2
+       rts

uptab   !byte STOCK,WASTE,WASTE,FOUND,FOUND+1,FOUND+2,FOUND+3
dntab   !byte TAB,TAB+1,TAB+3,TAB+4,TAB+5,TAB+6

; cur_d = la carta de dalt de la pila cur_p (0 si es buida)
curtop  ldx cur_p
        lda PLEN,x
        beq +
        sec
        sbc #1
+       sta cur_d
        rts
; A = index de la primera carta de cara de la columna cur_p (o la de dalt)
firstup ldx cur_p
        jsr pbase
        lda PLEN,x
        sta tmp
        ldy #0
-       cpy tmp
        bcs +
        lda (ptr),y
        bmi ++
        iny
        bne -
+       dey
        bpl ++
        iny
++      tya
        rts

; tornar a dibuixar la pila d'abans (tmp2) i la del cursor
redraw2 lda tmp2
        cmp cur_p
        beq drawpile_c
        jsr drawpile_o
drawpile_c
        ldx cur_p
        jmp drawpile
drawpile_o
        ldx tmp2
        cpx #MENU
        beq +
        jmp drawpile
+       rts

; =============================================================
;  BOTO
; =============================================================
fire    lda hsrc
        cmp #$ff
        bne fi_drop
        lda cur_p               ; ---- res agafat
        bne fi_take
        jmp draw3               ; munt: girar cartes
fi_take tax
        lda PLEN,x
        beq fi_x                ; pila buida
        cpx #TAB
        bcs +
        lda PLEN,x              ; descart i bases: la de dalt
        sec
        sbc #1
        sta cur_d
+       stx hsrc
        lda cur_d
        sta hstart
        ldx #SND_CLAC
        jsr sfx
        jmp drawpile_c
fi_x    rts
fi_drop lda cur_p               ; ---- deixar
        cmp hsrc
        bne fi_move
        ldx hsrc                ; a la mateixa pila: una sola carta va a la base si pot
        lda PLEN,x
        sec
        sbc hstart
        cmp #1
        bne fi_cancel
        jsr popx
        pha
        jsr pushx               ; (la torna a posar: nomes la mirem)
        pla
        jsr foundfor            ; X = base on va, o carry = no
        bcs fi_cancel
        stx cur_p
fi_move lda hsrc
        sta mv_s
        lda cur_p
        sta mv_d
        ldx hsrc
        lda PLEN,x
        sec
        sbc hstart
        sta mv_n
        jsr valid
        bcs fi_err
        jsr domove
        lda hsrc
        sta tmp2
        lda #$ff
        sta hsrc
        jsr redraw2b
        jmp checkwin
fi_err  ldx #SND_ERR
        jsr sfx
fi_cancel
        lda hsrc
        sta tmp2
        lda #$ff
        sta hsrc
        lda cur_p
        cmp tmp2
        beq +
        ldx tmp2
        jsr drawpile
+       jmp drawpile_c
redraw2b                        ; jugada feta: origen, desti i el que toqui
        ldx mv_s
        jsr drawpile
        ldx mv_d
        jsr drawpile
        jsr curtop
        jsr drawpile_c
        jmp status

; ---- base per a la carta A: X = base, C=0; C=1 si no n'hi ha
foundfor
        sta cc
        ldx #FOUND
-       stx mv_d
        lda #1
        sta mv_n
        jsr validf
        bcc +
        ldx mv_d
        inx
        cpx #FOUND+4
        bne -
        sec
        rts
+       ldx mv_d
        clc
        rts

; ---- es valida la jugada mv_s -> mv_d de mv_n cartes? C=0 si
valid   ldx mv_s                ; cc = la primera carta que es mou
        jsr pbase
        lda PLEN,x
        sec
        sbc mv_n
        tay
        lda (ptr),y
        sta cc
validf  lda mv_d
        cmp #TAB
        bcs va_tab
        cmp #FOUND
        bcc va_no               ; al munt o al descart, mai
        lda mv_n                ; ---- base: una carta, del mateix pal i un mes
        cmp #1
        bne va_no
        ldx mv_d
        jsr topx
        beq va_ace
        jsr split
        lda srank
        sta tmp
        lda ssuit
        sta tmp2
        lda cc
        jsr split
        lda ssuit
        cmp tmp2
        bne va_no
        ldx tmp
        inx
        cpx srank
        bne va_no
va_ok   clc
        rts
va_ace  lda cc
        jsr split
        lda srank
        beq va_ok
va_no   sec
        rts
va_tab  ldx mv_d                ; ---- columna: buida = rei (o qualsevol); si no, color contrari i un menys
        jsr topx
        bne +
        lda anyk
        bne va_ok
        lda cc
        jsr split
        lda srank
        cmp #12
        beq va_ok
        bne va_no
+       jsr split
        lda srank
        sta tmp
        lda ssuit
        sta tmp2
        lda cc
        jsr split
        lda ssuit
        eor tmp2
        lsr
        bcc va_no               ; mateix color
        ldx srank
        inx
        cpx tmp
        bne va_no
        beq va_ok

; A = carta -> srank (0-12), ssuit (0-3)
split   and #$3f
        ldx #0
-       cmp #13
        bcc +
        sbc #13
        inx
        bne -
+       sta srank
        stx ssuit
        rts

; ---- fer la jugada mv_s -> mv_d (mv_n cartes): punts, girar, desfer
domove  lda #0
        sta mv_f
        sta mv_sc
        lda mv_d                ; punts (Windows)
        cmp #TAB
        bcc dm_f
        lda mv_s
        cmp #WASTE
        bne +
        lda #5                  ; descart -> columna
        bne dm_sc
+       cmp #TAB
        bcs dm_mv
        lda #$f1                ; base -> columna: -15
        bne dm_sc
dm_f    lda mv_s                ; -> base: +10
        cmp #FOUND
        bcc +
        cmp #TAB
        bcc dm_mv
+       lda #10
dm_sc   sta mv_sc
dm_mv   jsr moveblk
        lda mv_s                ; columna d'origen: girar la nova de dalt
        cmp #TAB
        bcc +
        tax
        lda PLEN,x              ; (no Z de topx: l'as de piques de cara avall val 0)
        beq +
        jsr topx
        bmi +
        ora #$80
        sta (ptr),y
        inc mv_f
        lda mv_sc
        clc
        adc #5
        sta mv_sc
+       jsr addscore
        jsr pushundo
        inc moves
        bne +
        inc moves+1
+       ldx #SND_CLAC
        jmp sfx

; mou mv_n cartes de mv_s a mv_d mantenint l'ordre
moveblk ldx mv_s
        lda PLEN,x
        sec
        sbc mv_n
        sta tmp                 ; primera
        jsr pbase
        lda ptr
        sta num
        lda ptr+1
        sta num+1
        ldx mv_d
        jsr pbase
        ldy tmp
        ldx mv_d
-       sty tmp
        lda (num),y
        ldy PLEN,x
        sta (ptr),y
        inc PLEN,x
        ldy tmp
        iny
        tya
        ldx mv_s
        cmp PLEN,x
        ldx mv_d
        bcc -
        ldx mv_s
        lda tmp
        sec
        sbc mv_n
        clc
        adc #1
        sta PLEN,x
        rts

; punts += mv_sc (amb signe); mai per sota de 0 (mv_sc es queda amb el que s'ha sumat)
addscore
        lda mv_sc
        bpl +
        clc
        adc score
        tax
        lda score+1
        adc #$ff
        bcs ++                  ; no passa de 0
        lda score               ; si passava: es suma el que queda fins a 0
        eor #$ff
        clc
        adc #1
        sta mv_sc
        lda #0
        sta score
        sta score+1
        rts
++      stx score
        sta score+1
        rts
+       clc
        adc score
        sta score
        bcc +
        inc score+1
+       rts

; ---- desfer: pila de 4 bytes (origen|desti, nombre|girada, punts)
pushundo
        lda nund
        cmp #NUNDO
        bcc +
        jsr shiftundo
+       lda nund
        asl
        asl
        tay
        lda mv_s
        asl
        asl
        asl
        asl
        ora mv_d
        sta UNDO,y
        lda mv_f
        lsr
        ror
        ora mv_n
        sta UNDO+1,y
        lda mv_sc
        sta UNDO+2,y
        inc nund
        rts
shiftundo                       ; plena: s'oblida la mes antiga
        ldy #0
-       lda UNDO+4,y
        sta UNDO,y
        iny
        bne -
        dec nund
        rts
undo    lda nund
        bne +
        ldx #SND_ERR
        jmp sfx
+       dec nund
        lda nund
        asl
        asl
        tay
        lda UNDO,y
        lsr
        lsr
        lsr
        lsr
        sta mv_d                ; (al reves)
        lda UNDO,y
        and #$0f
        sta mv_s
        lda UNDO+1,y
        and #$7f
        sta mv_n
        lda UNDO+1,y
        sta mv_f
        lda UNDO+2,y
        eor #$ff
        clc
        adc #1
        sta mv_sc
        lda mv_f                ; la que es va girar torna avall
        bpl +
        ldx mv_d
        jsr topx
        and #$7f
        sta (ptr),y
+       lda mv_s
        cmp #WASTE+1
        bcs +
        lda mv_d                ; munt <-> descart: d'una en una (gira l'ordre)
        cmp #WASTE+1
        bcs +
        jsr movedeck
        jmp ++
+       jsr moveblk
++      jsr addscore
        inc moves
        bne +
        inc moves+1
+       lda #$ff
        sta hsrc
        ldx #SND_FREG
        jsr sfx
        jsr curtop
        jmp drawall

; ---- munt: girar 1 o 3 cartes al descart (o tornar-les totes si s'ha acabat)
draw3   lda PLEN+STOCK
        bne +
        lda PLEN+WASTE          ; munt buit: el descart torna al munt
        beq ++
        sta mv_n
        lda #WASTE
        sta mv_s
        lda #STOCK
        sta mv_d
        jsr movedeck
        lda #$ec                ; -20 (ROBA:3) o -100 (ROBA:1)
        ldx drawn
        cpx #3
        beq +++
        lda #$9c
+++     sta mv_sc
        jmp dr_end
+       lda drawn               ; n = min(drawn, munt)
        cmp PLEN+STOCK
        bcc +
        lda PLEN+STOCK
+       sta mv_n
        lda #STOCK
        sta mv_s
        lda #WASTE
        sta mv_d
        jsr movedeck
        lda #0
        sta mv_sc
dr_end  lda #0
        sta mv_f
        jsr addscore
        jsr pushundo
        ldx #SND_FREG
        jsr sfx
        ldx #STOCK
        jsr drawpile
        ldx #WASTE
        jsr drawpile
        jmp status
++      rts

; mv_n cartes de mv_s a mv_d d'una en una; al descart van de cara, al munt avall
movedeck
        lda mv_n
        sta tmp3
-       ldx mv_s
        jsr popx
        and #$3f
        ldx mv_d
        cpx #WASTE
        bne +
        ora #$80
+       jsr pushx
        dec tmp3
        bne -
        rts

; ---- partida guanyada?
checkwin
        lda PLEN+FOUND
        clc
        adc PLEN+FOUND+1
        adc PLEN+FOUND+2
        adc PLEN+FOUND+3
        cmp #52
        bne +
        sta won
        jsr fanfare
        jsr status
+       rts

; =============================================================
;  MENU
; =============================================================

; =============================================================
;  DIBUIX
; =============================================================
dp_p    = $42
dp_j    = $43
dp_n    = $44

drawall jsr clrscr
        jsr drawmenu
        jsr status
        ldx #12
-       txa
        pha
        jsr drawpile
        pla
        tax
        dex
        bpl -
        rts

Q4 = WIDTH*HEIGHT/4
clrscr  ldx #Q4                 ; tot tapet verd
-       lda #C_FELT
        sta SCREEN-1,x
        sta SCREEN-1+Q4,x
        sta SCREEN-1+2*Q4,x
        sta SCREEN-1+3*Q4,x
        lda #GREEN
        sta COLRAM-1,x
        sta COLRAM-1+Q4,x
        sta COLRAM-1+2*Q4,x
        sta COLRAM-1+3*Q4,x
        dex
        bne -
        ldx #3*WIDTH-1          ; files 0-2: blanc
        lda #C_BLANK
-       sta SCREEN,x
        dex
        bpl -
        rts

; ---- X = pila
drawpile
        stx dp_p
        lda #CARDT-2            ; alcada: les columnes, mes altes
        cpx #TAB
        bcc +
        lda #CARDH-2
+       jsr seth
        lda #GREEN              ; vora: groga si hi ha el cursor (a la carta de dalt)
        cpx cur_p
        bne +
        lda #YELLOW
+       sta edge
        lda #0
        sta full
        cpx #TAB
        bcc +
        jmp dp_tab
+       cpx #WASTE
        beq dp_wst
        lda topcol,x            ; ---- munt i bases: una casella
        sta col
        lda #ROWTOP
        sta row
        inc full
        lda PLEN,x
        beq dp_slot
        jsr topx
        sta cc
        jsr inkfor
        ldx dp_p
        cpx hsrc
        bne +
        lda #PURPLE
        sta ink
+       jmp drawcard
dp_slot jmp drawslot
dp_wst  lda #4                  ; ---- descart: ventall de fins a 3 (amb ROBA:3)
        sta col
        lda #ROWTOP
        sta row
        lda #$ff                ; (descart: 8 columnes)
        jsr clrrect
        ldx #WASTE
        lda PLEN,x
        bne +
        lda edge                ; buit: nomes es veu si hi ha el cursor
        cmp #YELLOW
        bne ++
        jmp drawslot
+       lda drawn
        cmp PLEN+WASTE
        bcc +
        lda PLEN+WASTE
+       sta dp_n
        lda PLEN+WASTE
        sec
        sbc dp_n
        sta dp_j
        lda edge
        pha
-       lda #GREEN
        sta edge
        dec dp_n
        bne +
        pla                     ; la de dalt: cursor i agafada
        sta edge
        pha
+       ldx #WASTE
        jsr pbase
        ldy dp_j
        lda (ptr),y
        sta cc
        jsr inkfor
        lda dp_n
        bne +
        lda hsrc
        cmp #WASTE
        bne +
        lda #PURPLE
        sta ink
+       lda #1
        sta full
        jsr drawcard
        inc col
        inc col
        inc dp_j
        lda dp_n
        bne -
        pla
++      rts

dp_tab  txa                     ; ---- columna
        sec
        sbc #TAB
        asl
        asl
        sta col
        lda #ROWTAB
        sta row
        lda PLEN,x
        bne +
        lda #ROWTAB+CARDH       ; buida: casella i tapet a sota
        pha
        jsr drawslot
        jmp dp_clr
+       sec                     ; si no hi caben, les primeres (tapades) no es dibuixen
        sbc #MAXN
        bcs +
        lda #0
+       sta dp_j
        lda edge
        sta tmp3                ; (groc si el cursor es en aquesta columna)
dp_lp   ldx dp_p
        jsr pbase
        ldy dp_j
        lda (ptr),y
        sta cc
        lda #GREEN
        sta edge
        lda tmp3
        cmp #YELLOW
        bne +
        lda dp_j
        cmp cur_d
        bne +
        lda #YELLOW
        sta edge
+       jsr inkfor
        lda hsrc
        cmp dp_p
        bne +
        lda dp_j
        cmp hstart
        bcc +
        lda #PURPLE
        sta ink
+       ldx dp_p
        lda dp_j
        clc
        adc #1
        cmp PLEN,x
        lda #0
        bcc +
        lda #1                  ; la darrera, sencera
+       sta full
        lda tmp3
        pha
        jsr drawcard
        pla
        sta tmp3
        inc row
        inc dp_j
        ldx dp_p
        lda dp_j
        cmp PLEN,x
        bcc dp_lp
        lda row                 ; tapet sota la darrera
        clc
        adc #CARDH-1
        pha
dp_clr  pla
        cmp #HEIGHT
        bcs +
        sta row
        lda #HEIGHT
        sec
        sbc row
        jmp clrrect
+       rts

; ---- alcada de les cartes: A files de cos (6 o 8)
seth    sta body
        lsr
        sec
        sbc #3
        sta boff
        rts

; ink = vermell o negre segons la carta cc
inkfor  lda cc
        jsr split
        lda ssuit
        and #1
        beq +
        lda #RED
+       sta ink                 ; (BLACK = 0)
        rts

; ---- tapet: A files des de (row, col), 4 columnes (o 8 si A=8: aleshores 6 files)
clrrect cmp #$ff
        bne +
        lda #CARDT              ; (descart: 8 columnes x CARDT files)
        sta tmp
        lda #8
        bne ++
+       sta tmp
        lda #4
++      sta tmp2
        ldx row
        ldy col
        jsr setrc
-       ldy tmp2
        dey
--      lda #C_FELT
        sta (sp),y
        lda #GREEN
        sta (cp),y
        dey
        bpl --
        jsr nextrow
        dec tmp
        bne -
        rts

; ---- caselles
setrc   tya                     ; X fila, Y columna -> sp, cp
        clc
        adc rowlo,x
        sta sp
        sta cp
        lda rowhi,x
        adc #0
        sta sp+1
        clc
        adc #>(COLRAM-SCREEN)
        sta cp+1
        rts
nextrow lda sp
        clc
        adc #WIDTH
        sta sp
        sta cp
        bcc +
        inc sp+1
        inc cp+1
+       rts
cell    sta (sp),y              ; A caracter a la columna Y, color pcol (A es conserva)
        pha
        lda pcol
        sta (cp),y
        pla
        rts

; ---- casella buida a (row, col), color edge
drawslot
        ldx row
        ldy col
        jsr setrc
        lda edge
        sta pcol
        ldy #0
        lda #C_SL_TL
        jsr cell
        lda #C_SL_T
        iny
        jsr cell
        iny
        jsr cell
        iny
        lda #C_SL_TR
        jsr cell
        lda body
        sta tmp2
-       jsr nextrow
        ldy #0
        lda #C_SL_L
        jsr cell
        lda #C_FELT
        iny
        jsr cell
        iny
        jsr cell
        iny
        lda #C_SL_R
        jsr cell
        dec tmp2
        bne -
        jsr nextrow
        ldy #0
        lda #C_SL_BL
        jsr cell
        lda #C_SL_B
        iny
        jsr cell
        iny
        jsr cell
        iny
        lda #C_SL_BR
        jmp cell

; ---- carta cc a (row, col): franja o sencera (full), vores edge, tinta ink
drawcard
        ldx row
        ldy col
        jsr setrc
        lda #C_TL
        sta tmp
        ldx #C_TR
        jsr edges
        lda cc
        bmi dc_face
        ldy #1                  ; ---- dors (pcol: el de les vores)
        lda #C_BK_TL
        jsr cell
        iny
        lda #C_BK_TR
        jsr cell
        lda full
        beq dc_x
        lda body
        sta tmp2
-       jsr nextrow
        lda #C_L
        sta tmp
        ldx #C_R
        jsr edges
        ldy #1
        lda #C_BK_ML
        jsr cell
        iny
        lda #C_BK_MR
        jsr cell
        dec tmp2
        bne -
        jsr nextrow
        lda #C_BL
        sta tmp
        ldx #C_BR
        jsr edges
        ldy #1
        lda #C_BK_BL
        jsr cell
        iny
        lda #C_BK_BR
        jmp cell
dc_x    rts
dc_face jsr split               ; ---- de cara
        lda ink
        sta pcol
        ldx srank
        lda rtop,x
        ldy #1
        jsr cell
        ldx ssuit
        lda stop,x
        iny
        jsr cell
        lda full
        beq dc_x
        lda #0                  ; cos: files 1-4
        sta tmp2
dc_row  jsr nextrow
        lda #C_L
        sta tmp
        ldx #C_R
        jsr edges
        lda tmp2                ; bt = fila del cos menys boff (cartes altes: tot una fila avall)
        sec
        sbc boff
        sta bt
        lda srank
        cmp #10
        bcc dc_pip
        lda bt                  ; figura a les files 1-4 de bt
        beq dc_bl
        cmp #5
        bcs dc_bl
        lda srank
        sec
        sbc #10                 ; figura: figtab + 8*(J,Q,K) + 2*fila
        asl
        asl
        asl
        sta tmp
        lda bt
        sbc #0                  ; (C=0: bt-1, fila 0-3 de la figura, files 2-5 del cos)
        asl
        adc tmp
        tax
        lda ssuit               ; roba: vermella o blava
        and #1
        beq +
        lda #MC+RED
        bne ++
+       lda #MC+BLUE
++      sta pcol
        ldy #1
        lda figtab,x
        jsr cell
        iny
        lda figtab+1,x
        jsr cell
        jmp dc_nx
dc_pip  lda ink                 ; pal gran a les files 3-4 del cos (2-3 de tmp2)
        sta pcol
        lda bt
        cmp #2
        bcc dc_bl
        cmp #4
        bcs dc_bl
        lda ssuit
        asl
        asl
        sta tmp
        lda bt
        sec
        sbc #2
        asl
        adc tmp
        tax
        ldy #1
        lda bigtab,x
        jsr cell
        iny
        lda bigtab+1,x
        jsr cell
        jmp dc_nx
dc_bl   ldy #1
        lda #C_BLANK
        jsr cell
        iny
        jsr cell
dc_nx   inc tmp2
        lda tmp2
        cmp body
        beq +
        jmp dc_row
+       jsr nextrow             ; fila de baix: pal i valor
        lda #C_BL
        sta tmp
        ldx #C_BR
        jsr edges
        lda ink
        sta pcol
        ldx ssuit
        lda sbot,x
        ldy #1
        jsr cell
        ldx srank
        lda rbot,x
        iny
        jmp cell

; ---- menu (fila 0): opcio del cursor en vermell
status  lda won
        beq +
        lda lang
        beq st_wca
        lda #<win_en
        ldx #>win_en
        bne st_w
st_wca  lda #<win_ca
        ldx #>win_ca
st_w    ldy #ROWSTAT
        sty row
        ldy #0
        sty col
        jsr ptext
        lda #RED
        bne st_col
+       lda lang
        beq +
        lda #<stat_en
        ldx #>stat_en
        bne ++
+       lda #<stat_ca
        ldx #>stat_ca
++      ldy #ROWSTAT
        sty row
        ldy #0
        sty col
        jsr ptext
        lda score
        ldx score+1
        ldy #7
        lda #4
        sta tmp2
        lda score
        jsr pdec
        lda moves
        ldx moves+1
        ldy #17
        lda #3
        sta tmp2
        lda moves
        jsr pdec
        lda mins
        ldx #0
        ldy #22
        lda #2
        sta tmp2
        lda mins
        jsr pdec
        lda #$ba                ; ":"
        sta SCREEN+ROWSTAT*WIDTH+24
        lda secs
        ldx #0
        ldy #25
        lda #2
        sta tmp2
        lda secs
        jsr pdec
        lda #BLACK
st_col  ldx #WIDTH-1
-       sta COLRAM+ROWSTAT*WIDTH,x
        dex
        bpl -
        rts

; ---- text de ptr (A/X) a (row, col), acabat amb 0; omple fins al final de la fila
ptext   sta ptr
        stx ptr+1
ptext2  ldx row
        ldy col
        jsr setrc
        ldy #0
-       lda (ptr),y
        beq +
        ora #$80
        sta (sp),y
        iny
        bne -
+       lda #$a0
-       cpy #WIDTH
        bcs +
        sta (sp),y
        iny
        bne -
+       rts

; ---- nombre A (baix) / X (alt) amb tmp2 xifres a la fila 1, columna Y
pdec    sta num
        stx num+1
        tya
        clc
        adc tmp2
        tay
-       dey
        sty tmp3
        jsr div10
        ora #$b0
        ldy tmp3
        sta SCREEN+ROWSTAT*WIDTH,y
        dec tmp2
        bne -
        rts
div10   ldx #16                 ; num /= 10, A = residu
        lda #0
-       asl num
        rol num+1
        rol
        cmp #10
        bcc +
        sbc #10
        inc num
+       dex
        bne -
        rts

menuch  and #$3f                ; lletra A (codi de pantalla) en negatiu a la columna Y
        tax
        lda rvtab,x
        sta SCREEN+ROWMENU*WIDTH,y
        rts

sndcol  !byte 16,15
sndtxt  !scr "si on no off"        ; [so][llengua]: SI ON / NO OFF
itemcol !byte 0,5,12,19, 0,5,10,19, 0,6,13,21, 0,10,16,22
itemlen !byte 5,7,7,9, 5,5,9,9, 6,7,8,7, 10,6,6,6

hush    lda #0                  ; s'acaba la musica
        sta mon
        sta mstep
        ldx #3
-       sta VOICE_L,x
        dex
        bpl -
        rts
mtick   lda mon                 ; (el reproductor viu on hi haura el desfer)
        beq +
        jmp mplay
+       rts
part_a
!if part_a > $1000 { !error "la primera part no hi cap: sobren ", part_a-$1000 }
        * = $1000
CSRC    !bin "charset.bin", NCHARS*8        ; (l'arrencada els copia a $1c00)
; ---- darrere dels caracters: l'arrencada tambe ho copia (a $1c00+NCHARS*8, que no es fa servir)
!pseudopc CHARSET+NCHARS*8 {
edges   lda edge                ; vores A (esquerra) i X (dreta) de la fila de la carta cc
        ldy cc
        bmi ed_f
        cmp #GREEN              ; dors: vores amb trama, vermelles (o grogues amb el cursor)
        bne +
        lda #RED
+       sta pcol
        txa
        clc
        adc #C_BEK
        pha
        lda tmp
        adc #C_BEK
        bcc ed_c                ; (sempre)
ed_f    sta pcol
        txa
        pha
        lda tmp
ed_c    ldy #0
        jsr cell
        pla
        ldy #3
        jmp cell
}
!if * > $13d4 { !error "les vores no hi caben: sobren ", *-$13d4 }
        * = $13d4               ; (despres de la pantalla)
; ---- joystick net: si es mou en diagonal (dos eixos alhora, com passa amb els joysticks
;      tactils), les direccions no compten; el boto si
joyclean
        jsr readjoy
        sta tmp
        and #$0c                ; vertical?
        beq +
        lda tmp
        and #$90                ; i horitzontal?
        beq +
        lda tmp
        and #$20
        rts
+       lda tmp
        rts

; ---- F1: entrar al menu o sortir-ne
f1menu  lda cur_p               ; F1: el cursor al munt (des d'on sigui)
        sta tmp2
        lda #STOCK
        sta cur_p
        jsr curtop
        jsr drawpile_o
        lda #0                  ; (fora del menu: s'oblida el de JOC)
        sta sub
        jsr drawmenu
        jmp drawpile_c
kycode  !byte 133,78,85,83,145,17,157,29,32,13,89
kyact   !byte $40,$41,$42,$43,$04,$08,$10,$80,$20,$20,$20
kyn = * - kyact

; =============================================================
;  PRESENTACIO: titol, quatre cartes i opcions (llengua, roba, columnes buides, so)
; =============================================================
drawmenu                        ; ---- barra del menu (fila ROWMENU) en negatiu
        lda sub
        asl
        ora lang
        tax
        lda mtlo,x
        sta ptr
        lda mthi,x
        sta ptr+1
        ldy #WIDTH-1
-       lda (ptr),y
        jsr menuch
        dey
        bpl -
        lda sub
        bne dm_col
        lda sound               ; SO:SI/NO, SFX:ON/OFF (3 lletres a la columna 18)
        asl
        ora lang
        sta tmp
        asl
        adc tmp                 ; x3
        tax
        ldy lang
        lda sndcol,y
        tay
        lda #3
        sta bt
-       lda sndtxt,x
        stx tmp
        jsr menuch
        ldx tmp
        inx
        iny
        dec bt
        bne -
dm_col  lda #BLUE               ; colors: blau, i l'opcio en vermell
        ldx #WIDTH-1
-       sta COLRAM+ROWMENU*WIDTH,x
        dex
        bpl -
        lda cur_p
        cmp #MENU
        bne +
        lda sub
        asl
        ora lang
        asl
        asl
        adc cur_m
        tax
        lda itemcol,x
        tay
        lda itemlen,x
        tax
        lda #RED
-       sta COLRAM+ROWMENU*WIDTH,y
        iny
        dex
        bne -
+       rts
; ---- fila 1: punts, jugades i temps (o el missatge de guanyar)

menuact lda sub
        beq ma_main
        lda #0                  ; ---- menu de JOC: nova partida, pista, sortir, tornar
        sta sub
        lda cur_m
        bne +
        jmp newgame
+       cmp #1
        bne +
        jmp hint
+       cmp #2
        bne +
        jmp quit
+       lda #0
        sta cur_m
        jmp drawmenu
ma_main lda cur_m
        bne ma_1
        lda cur_p               ; joc: un altre menu
        cmp #MENU
        beq +
        sta tmp2                ; (tecla N: cal anar al menu)
        lda #MENU
        sta cur_p
        jsr drawpile_o
+       inc sub
        lda #3                  ; (per defecte: tornar)
        sta cur_m
        jmp drawmenu
ma_1    cmp #1
        bne +
        jmp undo
+       cmp #2
        bne +
        lda sound               ; so
        eor #1
        sta sound
        jmp drawmenu
+       jmp intro               ; a la presentacio (opcions i llengua)

intro   lda ingame
        beq +
        lda won                 ; (partida comencada: es guarda)
        sta swon
        bcs ++                  ; (C=1: ingame=$ff)
+       lda sound               ; portada: musica
        bne ++
        jsr mstart
++      lda #$ff
        sta won                 ; (el temps no corre)
        lda #0
        sta iopt
in_draw ldx #Q4                 ; tot blanc
-       lda #C_BLANK
        sta SCREEN-1,x
        sta SCREEN-1+Q4,x
        sta SCREEN-1+2*Q4,x
        sta SCREEN-1+3*Q4,x
        dex
        bne -
        ldx #6*WIDTH            ; tapet de les files 9-20
-       lda #C_FELT
        sta SCREEN+9*WIDTH-1,x
        sta SCREEN+15*WIDTH-1,x
        lda #GREEN
        sta COLRAM+9*WIDTH-1,x
        sta COLRAM+15*WIDTH-1,x
        dex
        bne -
        ldx #0
        jsr titles
        lda ingame              ; partida comencada: "prem el boto per seguir"
        beq +
        lda #30
        sta row
        lda lang
        clc
        adc #30
        jsr strn
+       lda #CARDH-2
        jsr seth
        lda #$fe                ; les quatre cartes
        sta ianp
        jsr ianim
in_opts ldx #3                  ; opcions: etiqueta i valor
-       stx tmp3
        txa
        asl
        adc #22
        sta row
        lda #BLACK
        sta pcol
        lda #2
        sta col
        txa
        clc
        adc #4
        ldy lang
        beq +
        adc #4
+       jsr strn
        lda #C_BLANK            ; (columnes 0-1: potser hi havia la barra)
        ldy #1
        sta (sp),y
        dey
        sta (sp),y
        lda #13
        sta col
        ldx tmp3
        lda ivbase,x
        sta tmp
        cpx #0
        bne +
        lda tmp                 ; llengua: catala / english
        clc
        adc lang
        jmp iv_p
+       lda lang                ; roba, buides, so: 2 textos per llengua
        asl
        adc tmp
        sta tmp
        lda ivar-1,x
        tax
        lda 0,x
        cpx #drawn
        bne +
        lsr                     ; (roba 3 -> 0, 1 -> 1)
        eor #1
+       and #1
        clc
        adc tmp
iv_p    jsr strn
        ldx tmp3
        cpx iopt                ; l'opcio triada, en negatiu
        bne +
        ldy #WIDTH-1
--      lda (sp),y
        and #$3f
        tax
        lda rvtab,x
        sta (sp),y
        dey
        bpl --
        ldx tmp3
+       dex
        bpl -
il_lp   jsr wait
        jsr ianim
        jsr input
        beq il_lp
        tax
        and #$40                ; (tecles especials: res)
        bne il_lp
        txa
        and #$20                ; boto: a jugar (o a continuar la partida)
        beq il_dir
        jsr hush
        lda ingame
        beq +
        jmp resume
+       jmp newgame
il_dir  txa
        and #$0c
        beq il_lr
        and #$04
        beq +
        lda iopt                ; amunt
        beq il_lp
        dec iopt
        jmp in_opts
+       lda iopt                ; avall
        cmp #3
        bcs il_lp
        inc iopt
        jmp in_opts
il_lr   ldx iopt                ; esquerra o dreta: canvia l'opcio
        bne +
        lda lang
        eor #1
        sta lang
        jmp ++
+       dex
        bne +
        lda drawn
        eor #2
        sta drawn
        jmp ++
+       dex
        bne +
        lda anyk
        eor #1
        sta anyk
        jmp ++
+       lda sound
        eor #1
        sta sound
++      lda mon                 ; (clac, si no sona la musica)
        bne +
        ldx #SND_CLAC
        jsr sfx
+       lda sound
        beq +
        jsr hush                ; (so: no)
+       lda iopt                ; (la llengua ho canvia tot)
        bne +
        jmp in_draw
+       jmp in_opts

; ---- cartes de la portada: a cada nota de la musica, una es gira (ona d'esquerra a dreta)
ianim   jsr mtick
        lda mstep               ; (una carta a cada corxera)
        lsr
        cmp ianp
        beq ia_x
        sta ianp
        ldx #3
ia_lp   stx iak
        lda ianp
        beq ia_f
        and #3
        cmp iak
        bne ia_f
        lda icards,x
        and #$7f                ; de dors
        bpl +
ia_f    lda icards,x
+       sta cc
        lda icols,x
        sta col
        lda #10
        sta row
        lda #1
        sta full
        lda #GREEN
        sta edge
        jsr inkfor
        jsr drawcard
        ldx iak
        dex
        bpl ia_lp
ia_x    rts


; ---- PISTA: posa el cursor a una carta que es pot moure (a les bases primer), o al munt
hint    ldx #WASTE
hn_s    stx mv_s
        ldy PLEN,x
        beq hn_nx
        dey                     ; (descart: la de dalt)
        cpx #TAB
        bcc hn_go
        jsr pbase               ; columna: la primera de cara
-       lda (ptr),y
        bpl +
        dey
        bpl -
+       iny
hn_go   sty hst
        ldx #FOUND
hn_d    stx mv_d
        cpx mv_s
        beq hn_nd
        lda #1                  ; a una base, una carta
        cpx #TAB
        bcc +
        ldy mv_s                ; a una columna, totes les de cara
        lda PLEN,y
        sec
        sbc hst
        cpy #TAB
        bcc +
        ldy hst                 ; (tota una columna a una de buida no serveix)
        bne +
        ldy PLEN,x
        beq hn_nd
+       sta mv_n
        jsr valid
        bcc hn_ok
hn_nd   ldx mv_d
        inx
        cpx #TAB+7
        bne hn_d
hn_nx   ldx mv_s
        inx
        cpx #FOUND
        bne +
        ldx #TAB
+       cpx #TAB+7
        bne hn_s
        lda PLEN+STOCK          ; cap: al munt, si hi ha res per girar
        ora PLEN+WASTE
        bne +
        ldx #SND_ERR
        jsr sfx
        jmp drawmenu
+       lda #STOCK
        sta cur_p
        jsr curtop
        jmp hn_fi
hn_ok   ldx mv_s
        stx cur_p
        lda PLEN,x
        sec
        sbc mv_n
        sta cur_d
hn_fi   lda #0
        sta sub
        jmp drawall

resume  ldx #$ff                ; tornar a la partida, tal com era
        txs
        lda swon
        sta won
        jsr drawall
        jmp main



ititle  !byte 3,8,RED,$80, 5,10,BLUE,2, 7,6,BLACK,3, 30,3,BLUE,26|$80
        !byte 32,1,PURPLE,32|$80, 33,3,PURPLE,34|$80, 0     ; (no a la 34: ptext omple fins a col+28)
IQUIT = * - ititle
        !byte 13,8,YELLOW,$80, 16,2,WHITE,36, 19,5,CYAN,28|$80, 0
icards  !byte $80,$80+25,$80+37,$80+49
icols   !byte 3,9,15,21
ivbase  !byte 12,14,18,22
ivar    !byte drawn,anyk,sound
melody  !byte 0,195,201,207,215,207,215,219,219,0
mtlo    !byte <menu_ca,<menu_en,<sub_ca,<sub_en
mthi    !byte >menu_ca,>menu_en,>sub_ca,>sub_en
!source "harmonia.inc"
itexts  !scr "solitari pro",0,"solitaire pro",0,"klondike",0,"(c)jimsoft 2026",0
        !scr "idioma:",0,"roba:",0,"buides:",0,"so:",0
        !scr "language:",0,"draw:",0,"empty:",0,"sound:",0
        !scr "catala",0,"english",0
        !scr "3 cartes",0,"1 carta",0,"3 cards",0,"1 card",0
        !scr "nomes reis",0,"qualsevol",0,"kings only",0,"any card",0
        !scr "si",0,"no",0,"on",0,"off",0
        !scr "prem el boto per jugar",0,"press fire to play",0
        !scr "gracies per jugar!",0,"thanks for playing!",0
        !scr "prem el boto per seguir",0,"press fire to continue",0
        !scr "joystick o cursors+return",0,"joystick or cursors+return",0
        !scr "f1: munt    joc: pista",0,"f1: stock   game: hint",0
        !scr "(c)jimsoft & claude 2026",0

; =============================================================
;  DADES
; =============================================================
topcol  !byte 0,4,12,16,20,24
pblo    !byte <PILES,<(PILES+52)
        !for i, 0, 3 { !byte <(PILES+76+13*i) }
        !for i, 0, 3 { !byte <(TPILES+19*i) }
        !for i, 0, 2 { !byte <(TPILES2+19*i) }
pbhi    !byte >PILES,>(PILES+52)
        !for i, 0, 3 { !byte >(PILES+76+13*i) }
        !for i, 0, 3 { !byte >(TPILES+19*i) }
        !for i, 0, 2 { !byte >(TPILES2+19*i) }
;                 "0123456789012345678901234567"
menu_ca !scr     " joc  desfer so:si  opcions "
menu_en !scr     " game undo sfx:on   options "
sub_ca  !scr     " nova  pista  sortir  tornar"
sub_en  !scr     " new game  hint  quit  back "
stat_ca !scr " punts 0000  mov 000  00:00",0
stat_en !scr " score 0000  mov 000  00:00",0
win_ca  !scr " has guanyat! una altra? s/n",0
win_en  !scr " you win! another game? y/n",0
!source "cards.inc"
code_end
!if code_end > UNDO { !error "el programa no hi cap: sobren ", code_end-UNDO }

; =============================================================
;  MUSICA DE LA PORTADA, on despres hi haura el desfer: nomes sona abans de la primera
;  partida (es carrega aqui mateix; la primera jugada ja la trepitja)
; =============================================================
        * = UNDO
MTEMPO  = 9                     ; cicles per semicorxera
mstart  lda #1
        sta mtim
        sta mon
        lda #6                  ; (l'anacrusi: els dos darrers passos d'un compas buit)
        sta mstep
        lda #0
        sta mptr
        sta mhold
        sta hptr
        rts
mplay   lda #0
        sta VOICE_N             ; (el xarleston dura un cicle)
        dec mtim
        bne mp_x
        lda #MTEMPO
        sta mtim
        lda mhold               ; ---- melodia: nota (o $80 silenci) [+ passos de mes]
        beq +
        dec mhold
        bpl mp_h
+       ldy mptr
        lda mel,y
        beq mp_end
        iny
        cmp #$80
        bne +
        lda #0
+       sta VOICE_H
        lda mel,y
        bmi +
        beq +
        sta mhold
        iny
+       sty mptr
mp_h    lda mstep               ; ---- baix (oom) i acord (pah) amb xarleston
        inc mstep
        and #7
        tax
        lda psrc,x
        bmi +
        clc
        adc hptr
        tay
        lda harm,y
        !byte $2c               ; (bit: salta el lda #0)
+       lda #0
        ldy preg,x
        sta VOICE_L,y
        lda psrc,x
        cmp #2
        bne +
        lda #$f8
        sta VOICE_N
+       cpx #7
        bne mp_x
        lda hptr
        clc
        adc #3
        sta hptr
mp_x    rts
mp_end  jmp hush
psrc    !byte 0,$ff,2,$ff,1,$ff,2,$ff   ; d'on surt cada pas (baix 1, baix 2, acord)
preg    !byte 0,0,1,1,0,0,1,1           ; i a quina veu va
!source "musica.inc"     ; (la melodia; l'harmonia va amb el programa)
!if * > UNDO+$100 { !error "la musica no hi cap: sobren ", *-UNDO-$100 }

; =============================================================
;  CARREGAT A $1C00, I L'ARRENCADA HO COPIA AL FONS DE LA PILA ($0100-): la pila del joc
;  no baixa mai de $01e0
; =============================================================
        * = UNDO+$100
stk_src
!pseudopc $0100 {
; ---- titols des de ititle+X: fila (0: fi), columna, color, text (bit 7: + llengua)
titles  stx tmp3
        lda ititle,x
        beq ti_x
        sta row
        lda ititle+1,x
        sta col
        lda ititle+2,x
        sta pcol
        lda ititle+3,x
        bpl +
        and #$7f
        ora lang
+       jsr strn
        lda tmp3
        clc
        adc #4
        tax
        bne titles
ti_x    rts



; =============================================================
;  SORTIR: pantalla negra, credits, estrelles i reiniciar el VIC
; =============================================================
quit    lda #$08                ; fons i vora negres
        sta $900f
        jsr hush                ; silenci (A = 0 = C_BLANK)
        ldx #Q4
-       sta SCREEN-1,x          ; (C_BLANK = 0)
        sta SCREEN-1+Q4,x
        sta SCREEN-1+2*Q4,x
        sta SCREEN-1+3*Q4,x
        dex
        bne -
        ldx #IQUIT
        jsr titles
        lda #250                ; 5 s d'estrelles de colors que s'encenen i s'apaguen
        sta num
st_lp   jsr rnd                 ; posicio a l'atzar
        and #3
        tay
        lda rng
        cpy #3
        bne +
        cmp #<(WIDTH*HEIGHT)
        bcs st_lp
+       sta sp
        sta cp
        tya
        ora #>SCREEN
        sta sp+1
        tya
        ora #>COLRAM
        sta cp+1
        ldy #0
        lda (sp),y
        bpl st_ok               ; buit
        cmp #$a0                ; espai, "*" o "." (les lletres no es toquen)
        beq st_ok
        cmp #$aa
        beq st_ok
        cmp #$ae
        bne st_nx
st_ok   lda rng+1
        bmi st_big
        and #$40
        beq st_put              ; s'apaga (C_BLANK)
        lda #$ae                ; "."
        bne st_put
st_big  lda #$aa                ; "*"
st_put  sta (sp),y
        lda rng                 ; color a l'atzar (no negre)
        lsr
        lsr
        lsr
        and #7
        bne +
        lda #7
+       sta (cp),y
st_nx   lda JIFFY
-       cmp JIFFY
        beq -
        dec num
        bne st_lp
        jmp ($fffc)             ; reiniciar
; ---- text A-esim de itexts a (row, col), i la fila sencera del color pcol
strn    tax
        lda #<itexts
        sta ptr
        lda #>itexts
        sta ptr+1
--      dex
        bmi +
-       ldy #0
        lda (ptr),y
        inc ptr
        bne ++
        inc ptr+1
++      cmp #0
        bne -
        beq --
+       jsr ptext2
        ldx row
        ldy #0
        jsr setrc
        ldy #WIDTH-1
        lda pcol
-       sta (cp),y
        dey
        bpl -
        rts

}
stk_len = * - stk_src
!if stk_len > $d8 { !error "el bloc de la pila no hi cap: sobren ", stk_len-$d8 }

; ---- arrencada (nomes es fa servir un cop, abans de copiar-hi els caracters)
boot2   ldx #15                 ; VIC: pantalla $1000, caracters $1c00, 28x35
-       lda vicini,x
        sta $9000,x
        dex
        bpl -
        ldx #stk_len            ; bloc del fons de la pila
-       lda stk_src-1,x
        sta+2 $00ff,x
        dex
        bne -
        lda #<SCREEN            ; adreces de les files
        ldy #>SCREEN
-       sta rowlo,x
        sty rowhi,x
        clc
        adc #WIDTH
        bcc +
        iny
+       inx
        cpx #HEIGHT
        bne -
        rts
vicini  !byte $06,$0f,WIDTH,HEIGHT*2,0,$cf,0,0,0,0,0,0,0,0,$9a,$18  ; aux taronja clar, volum 10; fons blanc
!if * > $1e00 { !error "l'arrencada passa de $1dff" }
