#!/usr/bin/env python3
"""SOLITARI PRO - joc de caracters de les cartes petites (4x6 caselles) i maqueta.
Escriu charset.bin (128 caracters per a $1c00), cards.inc (codis per a ACME) i maqueta_real.png
(una partida dibuixada amb aquests caracters, com ho faria el VIC).
Carta de 4x6: fila 0  [TL][valor][pal][TR]       (la franja que es veu a les columnes)
              files 1-4 [L][   cos 2x4  ][R]        (pal gran 2x2, o figura 2x4 multicolor)
              fila 5  [BL][pal][valor][BR]
Les vores (TL TR L R BL BR) son verdes (el tapet): fan les cantonades arrodonides i el
marge de 2 pixels entre columnes. El cos de la carta es el fons blanc."""
import sys
from PIL import Image, ImageDraw
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from font import ROM

def g(rows):
    assert len(rows) == 8 and all(len(r) == 8 for r in rows), rows
    return [[1 if c == '#' else 0 for c in r] for r in rows]
def hb(gl):
    return bytes(sum(b << (7 - x) for x, b in enumerate(r)) for r in gl)
def mb(rows):  # multicolor: 4 pixels per fila, valors 0-3
    return bytes((r[0] << 6) | (r[1] << 4) | (r[2] << 2) | r[3] for r in rows)
def rom(ch, down=0):  # caracter de la ROM, baixat 'down' files
    h = ROM[ch]
    rows = [int(h[i*2:i*2+2], 16) for i in range(8)]
    return bytes([0]*down + rows[:8-down])

chars = []
names = {}
def add(name, data):
    assert len(data) == 8
    if data in chars:
        names[name] = chars.index(data)
    else:
        names[name] = len(chars)
        chars.append(data)
    return names[name]

add('BLANK', bytes(8))
add('FELT', bytes([255]*8))
# ---- vores (verd, en alta resolucio)
add('TL', hb(g(['########', '###.....', '##......', '#.......', '#.......', '#.......', '#.......', '#.......'])))
add('TR', hb(g(['########', '.....###', '......##', '.......#', '.......#', '.......#', '.......#', '.......#'])))
add('L',  hb(g(['#.......']*8)))
add('R',  hb(g(['.......#']*8)))
add('BL', hb(g(['#.......', '#.......', '#.......', '#.......', '#.......', '##......', '###.....', '########'])))
add('BR', hb(g(['.......#', '.......#', '.......#', '.......#', '.......#', '......##', '.....###', '########'])))
# ---- index: valor i pal, a dalt (baixats 1 fila: blanc a la fila 0 fa de separacio) i a baix
SUIT = {'S': ['...#....', '..###...', '.#####..', '#######.', '#######.', '...#....', '.#####..'],
        'H': ['.##.##..', '#######.', '#######.', '.#####..', '..###...', '...#....', '........'],
        'D': ['...#....', '..###...', '.#####..', '#######.', '.#####..', '..###...', '...#....'],
        'C': ['..###...', '..###...', '##.#.##.', '#######.', '##.#.##.', '...#....', '.#####..']}
TEN = ['.#..##..', '##.#..#.', '.#.#..#.', '.#.#..#.', '.#.#..#.', '.#.#..#.', '.#..##..']
RANKS = 'A23456789TJQK'
for r in RANKS:
    if r == 'T':
        add('RT_T', hb(g(['........'] + TEN)))
        add('RB_T', hb(g(TEN + ['........'])))
    else:
        add('RT_' + r, rom(r, 1))
for s in 'SHDC':
    add('ST_' + s, hb(g(['........'] + SUIT[s])))
    add('SB_' + s, hb(g(SUIT[s] + ['........'])))
# ---- pals grans: 2x2 caselles (16x16), dibuixats en vectorial i reduits
def bigsuit(kind):
    S = 8; N = 16; W = N*S
    im = Image.new('L', (W, W), 0); d = ImageDraw.Draw(im)
    cx = W/2; sw = 7*S
    if kind in 'HS':
        r = sw/2
        if kind == 'H':
            d.ellipse([cx-sw, 1*S, cx, 1*S+2*r], fill=255); d.ellipse([cx, 1*S, cx+sw, 1*S+2*r], fill=255)
            d.polygon([(cx-sw+S*0.2, 1*S+r*1.2), (cx+sw-S*0.2, 1*S+r*1.2), (cx, W-1*S)], fill=255)
        else:
            d.ellipse([cx-sw, W-5*S-2*r, cx, W-5*S], fill=255); d.ellipse([cx, W-5*S-2*r, cx+sw, W-5*S], fill=255)
            d.polygon([(cx-sw+S*0.2, W-5*S-r*1.2), (cx+sw-S*0.2, W-5*S-r*1.2), (cx, 0)], fill=255)
            d.polygon([(cx-S*0.7, W-7*S), (cx+S*0.7, W-7*S), (cx+S*3, W-1*S), (cx-S*3, W-1*S)], fill=255)
    if kind == 'D':
        d.polygon([(cx, 0), (cx+sw*0.85, W/2), (cx, W), (cx-sw*0.85, W/2)], fill=255)
    if kind == 'C':
        r = sw*0.47
        d.ellipse([cx-r, 0, cx+r, 2*r], fill=255)
        d.ellipse([cx-sw, 5*S, cx-sw+2*r, 5*S+2*r], fill=255)
        d.ellipse([cx+sw-2*r, 5*S, cx+sw, 5*S+2*r], fill=255)
        d.polygon([(cx-S*0.8, 6*S), (cx+S*0.8, 6*S), (cx+S*3, W-1*S), (cx-S*3, W-1*S)], fill=255)
    sm = im.resize((N, N), Image.BOX)
    px = [[1 if sm.getpixel((x, y)) > 110 else 0 for x in range(N)] for y in range(N)]
    return [[[[px[r*8+y][c*8+x] for x in range(8)] for y in range(8)] for c in range(2)] for r in range(2)]
for s in 'SHDC':
    b = bigsuit(s)
    for r in range(2):
        for c in range(2):
            add('BIG_%s%d%d' % (s, r, c), hb(b[r][c]))
# ---- figures: 2x4 caselles multicolor (8x32 pixels amples). '.' blanc, 'k' negre (vora),
#      'a' auxiliar (taronja clar: pell i or), 'c' color de la casella (vermell o blau)
FIG = {
'K': """
.a.aa.a.
.aaaaaa.
.akaaka.
.kkkkkk.
kaaaaaak
kakaakak
kaaaaaak
kkaaaakk
kkkkkkkk
.kkkkkk.
..kkkk..
.caaaac.
ccaccacc
ccaccacc
ccaaaacc
ccaccacc
ccaccacc
caaccaac
ccaccacc
ccaccacc
ccaaaacc
ccaccacc
ccaccacc
caaccaac
ccaccacc
ccaccacc
ccaaaacc
ccaccacc
.caccac.
.cc..cc.
.kk..kk.
kkk..kkk
""",
'Q': """
..aaaa..
.akaaka.
..aaaa..
..kkkk..
.kkaakk.
kkakkakk
kkaaaakk
kkaakakk
kkkaakkk
kk.aa.kk
k..aa..k
..cccc..
.caaaac.
ccaccacc
ccaaaacc
cccaaccc
ccaccacc
ccaaaacc
cccaaccc
ccaccacc
ccaaaacc
cccaaccc
ccaccacc
ccaaaacc
cccaaccc
ccaccacc
ccaaaacc
cccaaccc
cccccccc
.cccccc.
.kk..kk.
kkk..kkk
""",
'J': """
..cccc..
.cccccc.
.ckkkkc.
ccaaaacc
.kakkak.
.kaaaak.
.kaakak.
..aaaa..
..kkkk..
...aa...
.cccccc.
ccaccacc
caaaaaac
ccaccacc
ccaccacc
ccaccacc
cakkkkac
ccaccacc
ccaccacc
ccaccacc
ccaccacc
cakkkkac
ccaccacc
.caccac.
.caccac.
.kk..kk.
.kk..kk.
.kk..kk.
.kk..kk.
.kk..kk.
kkk..kkk
kkk..kkk
"""}
V = {'.': 0, 'k': 1, 'c': 3, 'a': 2}
for f, art in FIG.items():
    rows = [l for l in art.strip().split('\n')]
    assert len(rows) == 32 and all(len(r) == 8 for r in rows), (f, len(rows))
    for r in range(4):
        for c in range(2):
            cell = [[V[ch] for ch in rows[r*8+y][c*4:c*4+4]] for y in range(8)]
            add('FIG_%s%d%d' % (f, r, c), mb(cell))
# ---- dors (vermell, alta resolucio): trama de rombes fins a les vores. Fa 32 pixels d'ample:
#      les vores tambe en porten (BE_*, en vermell, o grogues amb el cursor); 1 pixel blanc
#      de separacio, la ratlla vermella i la trama
def backcard():
    W, Hh = 32, 24
    px = [[0]*W for _ in range(Hh)]
    for y in range(Hh):
        for x in range(W):
            if x in (0, W-1) or y in (0, Hh-1):
                v = 0
            elif x in (1, W-2) or y in (1, Hh-2):
                v = 1
            else:
                v = 1 if (x + y) % 8 == 0 or (x - y) % 8 == 0 else 0
            px[y][x] = v
    return px
BK = backcard()
def bcell(r, c):
    return [[BK[r*8+y][c*8+x] for x in range(8)] for y in range(8)]
for r, nm in [(0, 'T'), (1, 'M'), (2, 'B')]:
    for c, cn in [(1, 'L'), (2, 'R')]:
        add('BK_%s%s' % (nm, cn), hb(bcell(r, c)))
# ---- casella buida (bases, munt): vora blanca puntejada sobre el verd
add('SL_TL', hb(g(['########', '########', '##.#.#.#', '##.#####', '########', '##.#####', '########', '##.#####'])))
add('SL_T',  hb(g(['########', '########', '.#.#.#.#', '########', '########', '########', '########', '########'])))
add('SL_TR', hb(g(['########', '########', '.#.#.###', '#####.##', '########', '#####.##', '########', '#####.##'])))
add('SL_L',  hb(g(['########', '##.#####', '########', '##.#####', '########', '##.#####', '########', '##.#####'])))
add('SL_R',  hb(g(['########', '#####.##', '########', '#####.##', '########', '#####.##', '########', '#####.##'])))
add('SL_BL', hb(g(['########', '##.#####', '########', '##.#####', '########', '##.#.#.#', '########', '########'])))
add('SL_B',  hb(g(['########', '########', '########', '########', '########', '.#.#.#.#', '########', '########'])))
add('SL_BR', hb(g(['########', '#####.##', '########', '#####.##', '########', '.#.#.###', '########', '########'])))
# ---- lletres en negatiu per a la barra del menu (l'espai en negatiu es FELT, el bloc ple)
RV = 'NOVADESFRICWUXM:PTGQBKJHLY13'
for ch in RV:
    add('RV_' + ('CO' if ch == ':' else ch), bytes(255 - b for b in rom(ch)))
# vores del dors: al mateix ordre que les de la carta (TL TR L R BL BR), a distancia fixa
for nm, r, c in [('TL', 0, 0), ('TR', 0, 3), ('L', 1, 0), ('R', 1, 3), ('BL', 2, 0), ('BR', 2, 3)]:
    n = len(chars)
    add('BE_' + nm, hb(bcell(r, c)))
    assert names['BE_' + nm] == n and n - names[nm] == len(chars) - 1 - names['BR'] + names[nm] - names[nm] or True
BEK = names['BE_TL'] - names['TL']
assert all(names['BE_' + nm] - names[nm] == BEK for nm in ['TL', 'TR', 'L', 'R', 'BL', 'BR'])
print('caracters:', len(chars), 'de 128')
assert len(chars) <= 128
open('charset.bin', 'wb').write(b''.join(chars) + bytes(8*(128-len(chars))))

# ================= maqueta amb els caracters reals =================
WIDTH, HEIGHT = 28, 35
BLACK, WHITE, RED, CYAN, PURPLE, GREEN, BLUE, YELLOW = range(8)
MC = 8
PAL = [(0,0,0),(255,255,255),(182,31,33),(77,240,255),(180,63,255),(68,226,55),(26,52,255),(220,215,27),
       (202,84,0),(233,176,114),(231,146,147),(154,247,253),(224,159,255),(143,228,147),(130,144,255),(229,222,133)]
scr = [[names['FELT']]*WIDTH for _ in range(HEIGHT)]
col = [[GREEN]*WIDTH for _ in range(HEIGHT)]
def put(r, c, ch, cl):
    scr[r][c] = ch; col[r][c] = cl
def text(r, c, s, cl):
    for i, ch in enumerate(s):
        o = ord(ch)
        put(r, c+i, 0x80 | (o - 64 if 65 <= o <= 90 else o), cl)
def card(r, c, rank, s, full, cursor=False, held=False):
    ink = RED if s in 'HD' else BLACK
    if held: ink = PURPLE
    edge = YELLOW if cursor else GREEN
    put(r, c, names['TL'], edge); put(r, c+3, names['TR'], edge)
    rk = names['RT_' + rank] if rank != 'T' else names['RT_T']
    put(r, c+1, rk, ink); put(r, c+2, names['ST_' + s], ink)
    if not full:
        return
    for y in range(1, 5):
        put(r+y, c, names['L'], edge); put(r+y, c+3, names['R'], edge)
        put(r+y, c+1, names['BLANK'], ink); put(r+y, c+2, names['BLANK'], ink)
    if rank in 'JQK':
        robe = RED if s in 'HD' else BLUE
        for y in range(4):
            for x in range(2):
                put(r+1+y, c+1+x, names['FIG_%s%d%d' % (rank, y, x)], MC + robe)
    else:
        for y in range(2):
            for x in range(2):
                put(r+2+y, c+1+x, names['BIG_%s%d%d' % (s, y, x)], ink)
    put(r+5, c, names['BL'], edge); put(r+5, c+3, names['BR'], edge)
    put(r+5, c+1, names['SB_' + s], ink)
    put(r+5, c+2, names['RB_T'] if rank == 'T' else 0x80 | (ord(rank) - 64 if rank.isalpha() else ord(rank)), ink)
def back(r, c, full):
    put(r, c, names['TL'], GREEN); put(r, c+3, names['TR'], GREEN)
    put(r, c+1, names['BK_TL'], RED); put(r, c+2, names['BK_TR'], RED)
    if full:
        for y in range(1, 5):
            put(r+y, c, names['L'], GREEN); put(r+y, c+3, names['R'], GREEN)
            put(r+y, c+1, names['BK_ML'], RED); put(r+y, c+2, names['BK_MR'], RED)
        put(r+5, c, names['BL'], GREEN); put(r+5, c+3, names['BR'], GREEN)
        put(r+5, c+1, names['BK_BL'], RED); put(r+5, c+2, names['BK_BR'], RED)
def slot(r, c):
    put(r, c, names['SL_TL'], GREEN); put(r, c+1, names['SL_T'], GREEN); put(r, c+2, names['SL_T'], GREEN); put(r, c+3, names['SL_TR'], GREEN)
    for y in range(1, 5):
        put(r+y, c, names['SL_L'], GREEN); put(r+y, c+3, names['SL_R'], GREEN)
    put(r+5, c, names['SL_BL'], GREEN); put(r+5, c+1, names['SL_B'], GREEN); put(r+5, c+2, names['SL_B'], GREEN); put(r+5, c+3, names['SL_BR'], GREEN)
if __name__ == '__main__':
    for c in range(WIDTH):
        put(0, c, 0xa0, BLUE)
    text(0, 0, ' NOVA DESFER ROBA:3 SO ENG ', BLUE)
    text(1, 0, ' PUNTS  135   MOV  37  4:12 ', BLACK)
    for c in range(WIDTH):
        col[1][c] = BLACK
    back(2, 0, True); card(2, 4, '7', 'D', True)
    card(2, 12, '3', 'H', True); card(2, 16, 'A', 'S', True); slot(2, 20); slot(2, 24)
    cols = [[('K','S'),('Q','H'),('J','C'),('T','D'),('9','S')],
            [None,('8','H')],
            [None,None,('Q','C'),('J','D')],
            [None,None,None,('5','S'),('4','H'),('3','C')],
            [None,None,None,None,('K','H'),('Q','S'),('J','H'),('T','C'),('9','H'),('8','S'),('7','D')],
            [None,None,None,None,None,('6','C')],
            [None,None,None,None,None,None,('2','D')]]
    for c, pile in enumerate(cols):
        for i, k in enumerate(pile):
            last = i == len(pile) - 1
            if k is None:
                back(9+i, c*4, last)
            else:
                card(9+i, c*4, k[0], k[1], last, cursor=(c == 3 and i == 3), held=(c == 0 and i >= 2))
    # renderitzat com el VIC: fons blanc, vora negra, auxiliar taronja clar
    bg, border, aux = WHITE, BLACK, 9
    cs = b''.join(chars) + bytes(8*(128-len(chars)))
    im = Image.new('RGB', (WIDTH*8, HEIGHT*8)); px = im.load()
    for r in range(HEIGHT):
        for c in range(WIDTH):
            v = scr[r][c]; cl = col[r][c]
            if v >= 128:
                ch = chr(64 + (v - 128)) if 1 <= v - 128 <= 26 else chr(v - 128)
                gl = rom(ch) if ch in ROM else bytes(8)
            else:
                gl = cs[v*8:v*8+8]
            for y in range(8):
                b = gl[y]
                for x in range(8):
                    if cl & 8:
                        p = (b >> (6 - (x//2)*2)) & 3
                        rgb = PAL[[bg, border, cl & 7, aux][p]]
                    else:
                        rgb = PAL[cl & 7] if (b >> (7-x)) & 1 else PAL[bg]
                    px[c*8+x, r*8+y] = rgb
    out = Image.new('RGB', (WIDTH*8*3+40, HEIGHT*8*3+40), PAL[border])
    out.paste(im.resize((WIDTH*8*3, HEIGHT*8*3), Image.NEAREST), (20, 20))
    out.save('maqueta_real.png')
    L = ['; ---- generat per genera_cartes.py ----'] + ['C_%-8s = %d' % (k, v) for k, v in names.items()]
    L.append('C_BEK    = %d             ; vora del dors = vora de la carta + C_BEK' % BEK)
    def tab(nm, vals):
        L.append('%-8s !byte %s' % (nm, ','.join('$%02x' % v for v in vals)))
    SU = 'SHCD'                                    # pals del joc: 0 piques 1 cors 2 trebols 3 diamants
    tab('rtop', [names['RT_' + r] for r in RANKS])
    tab('rbot', [names['RB_T'] if r == 'T' else 0x80 | (ord(r) - 64 if r.isalpha() else ord(r)) for r in RANKS])
    tab('stop', [names['ST_' + s] for s in SU])
    tab('sbot', [names['SB_' + s] for s in SU])
    tab('bigtab', [names['BIG_%s%d%d' % (s, r, c)] for s in SU for r in range(2) for c in range(2)])
    rv = [names['FELT']] * 64
    for ch in RV:
        rv[ord(ch) - 64 if ch.isalpha() else ord(ch)] = names['RV_' + ('CO' if ch == ':' else ch)]
    tab('rvtab', rv)
    tab('figtab', [names['FIG_%s%d%d' % (f, r, c)] for f in 'JQK' for r in range(4) for c in range(2)])
    open('cards.inc', 'w').write('\n'.join(L) + '\n')
